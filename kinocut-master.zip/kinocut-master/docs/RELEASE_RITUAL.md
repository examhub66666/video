# Release ritual (on-domain marketing)

Minimum marketing steps when cutting a public Kinocut release. Engineering release process remains in CI/publish workflows.

**For the completed 1.8.0 cutover**, use the record and published notes below for audit; for a future release, use this ritual with that release's version and fresh gates:

- [`RELEASE_1.8_CHECKLIST.md`](RELEASE_1.8_CHECKLIST.md)
- [`scripts/apply_public_release_cutover.py`](../scripts/apply_public_release_cutover.py)
- Published notes: [`status/2026-07-14-1.8-release-notes.md`](status/2026-07-14-1.8-release-notes.md)

## 0. Authority

Land through a reviewed GitHub pull request with exact-head GitHub CI green.
Create release tags and GitHub Releases from the canonical GitHub history. Forgejo
is a downstream mirror and must receive release commits only through the verified
GitHub-to-Forgejo downstream sync; normal release changes must not be independently merged
there. The downstream sync is pending live-gate verification, so report any
lag without claiming mirror completion. Do not set `published_version` until
`scripts/verify_published_claims_live.py` is green for that version (PyPI already
serves it).

## 1. Freeze claims

Update [`public_claims.json`](public_claims.json):

- `published_version`, `published_date`
- `published_mcp_tools`, `published_cli_commands` (from public surface tests on the release tag)
- Keep `development_*` equal to published at tag time, or leave tip higher only on post-release master

**Ultragoal claim freeze (active until L3):** only the ultragoal **claim owner**
(ledger leader for `kinocut-full-build`, or product override) may bump
`public_claims.json` during the residual portfolio. Non-owners must not opportunistically
sync tip counts. See [`ROADMAP.md`](../ROADMAP.md) claim ledger and
[`status/2026-08-12-l1-truth-pass.md`](status/2026-08-12-l1-truth-pass.md).
## 2. Verify

```bash
pytest tests/test_public_claims.py tests/test_public_surface.py -q
python scripts/verify_published_claims_live.py
python scripts/golden_path.py
```

`scripts/apply_public_release_cutover.py` defaults to `--require-live` (PyPI 200 for
the new `published_version`).

## 3. Ship package + registry

Follow existing publish workflow (PyPI, MCP Registry recovery if needed).

## 4. Three agent-facing bullets

Write exactly three bullets for:

- GitHub Release body  
- kinocut.dev `/changelog.html` (or site changelog page)  
- Social / directories  

Format:

1. What agents can do now  
2. What got safer (guardrail/receipt/doctor)  
3. Compat note (if any)

## 5. Proof link

If golden path or a demo pack was re-run, link `docs/GOLDEN_PATH.md` or a dated proof under `docs/proofs/`.

## 6. Directories

Walk [DIRECTORY_STATUS.md](DIRECTORY_STATUS.md) board; open/refresh tickets.

## 7. Site

If version messaging on kinocut.dev is hardcoded, bump to match `published_version` (facts strip, JSON-LD, llms.txt).
