# Product pipeline complete (1.13.4)

**Date:** 2026-08-12  
**Branch:** `product/pipeline-complete`  
**Scope:** Phase 3/4 GO, Track E GO, sound S14/S15 maturity, G004 synthetic fixtures, MCPB pack checklist — **not** human growth programs.

**Current scope amendment (2026-10-01):** this is a historical checkpoint, not a
current full-episode sound or listening acceptance receipt. Supported sound claims
cover the implemented deterministic processing, measured policy contracts and
retained synthetic/resource controls. A representative Apple-host episode and
human listening review remain unverified. The current MCPB direction is the
staged `user-configured-local-access` launcher; native bundles are separate scope.
See [the current supported-scope decisions](../research/debt-closure-operations.md).

## Phase exits

| Phase | Exit | Evidence |
|-------|------|----------|
| 1 Kernel | GO (prior) | projectstore |
| 2 JTBD | GO (prior) | intent/broll/translate |
| 3 Watching | **GO** | `tests/test_phase3_watching_go.py` |
| 4 Multipliers | **GO** | `tests/test_phase4_multipliers_go.py` |
| Track E | **GO** | `tests/test_track_e_go.py` + public cutfile-render |

## Public surface delta

| | Before | After |
|--|--------|-------|
| MCP tools | 194 | **196** (`video_cutfile_render`, `video_metric_qc`) |
| CLI commands | 165 | **167** (`cutfile-render`, `metric-qc`) |

## Sound

- S14 live re-run: `docs/evidence/2026-08-12-sound-s14-live-rerun.json` (64 clips, under_30m, apple_silicon)
- Second class: `external_host_unavailable` (gate-allowed)
- S15 tests green

## G004

- Synthetic multi-shot 9:16 fixture generator: `scripts/make_g004_fixtures.py`
- Review path exercised in `tests/test_g004_and_mcpb_product.py`

## MCPB

- `scripts/mcpb_production_pack.py` + clean-machine checklist
- **No signing key available** — unsigned pack is the product path. Not a blocker.
  Install product via `pip install kinocut` / MCP stdio; signed multi-platform MCPB only if keys exist later.

**Correction (2026-09-06):** the emitted clean-machine checklist was planning evidence, not an
executed clean-machine install or a readiness result. Current MCPB status comes from exact-digest
validator, hosted-runtime, desktop-install, signing, publication, and human-review receipts.

## Intentionally out of product timeline

Directories, launch publish, first-10 users, Renovate host token, CI light runner topology.
