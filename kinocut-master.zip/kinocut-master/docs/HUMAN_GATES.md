# Human / ops residual (updated 2026-10-05)

Agent-closable prep is on tip. Live outcomes below still need a human operator
where noted. Residual portfolio authority:
[`docs/status/2026-08-12-residual-maturity-matrix.md`](status/2026-08-12-residual-maturity-matrix.md)
· [L1 truth pass](status/2026-08-12-l1-truth-pass.md)
· [DEFERRED](status/DEFERRED.md).

| Former issue | Agent deliverable | Status |
| --- | --- | --- |
| #3 Renovate dashboard | `.github/dependabot.yml` + superseded Forgejo setup in [`docs/ops/RENOVATE_HOST_TOKEN.md`](ops/RENOVATE_HOST_TOKEN.md) | GitHub Dependabot is canonical; do not provision the old Forgejo Renovate tokens for Kinocut |
| #88 Directory submissions | `docs/DIRECTORY_REBRAND_STATUS.md` + `docs/status/DIRECTORY_SUBMISSION_OPS.md` | Older Awesome MCP Servers PR #9817 **merged** (2026-08-08); later [PR #15050](https://github.com/punkpeye/awesome-mcp-servers/pull/15050) remains open. MCP.so, Docker MCP, Agent-CoreX and Protodex submissions remain open (verified 2026-10-05); submission is not directory acceptance. |
| #90 Launch moments | `docs/status/LAUNCH_MOMENTS.md` drafts + checklists | Approve & publish posts/clips (marketing ops, not product maturity) |
| #92 First-10 users | `docs/status/USER_PROGRAM_RUNBOOK.md` | **CLOSED as obsolete (2026-08-12)** — adoption already past a “first 10” gate (see live signals below) |

## Live adoption signals (re-verified 2026-08-12; package 2026-09-30)

| Signal | Value | Source |
| --- | --- | --- |
| GitHub stars | **107** | `gh api repos/KyaniteLabs/kinocut` |
| GitHub forks | **25** | same |
| PyPI downloads (last day) | **608** | pypistats / pypi.org API |
| PyPI downloads (last week) | **6,715** | same |
| PyPI downloads (last month) | **23,034** | same |
| Published package | **2.0.1** | PyPI (published/verified 2026-11-10); historical download/star observations above remain dated |

Downloads are not a unique-user census, but stars + forks + multi‑k weekly installs
make “recruit first 10 users” an obsolete product gate. Do **not** re-open #92 as
incomplete pipeline work.

## Downstream policy activation

The GitHub-to-Forgejo workflow contains a staged activation guard. Current activation
is **unverified**: the repository variable read returned HTTP 401 on 2026-10-05.
Source configuration alone does not prove that the workflow is inactive. Both jobs require the
repository variable `KINOCUT_FORGEJO_SYNC_ACTIVE` to compare equal to `true`
under GitHub Actions' case-insensitive string equality. Values such as `true`,
`True`, and `TRUE` activate both jobs; other values do not. Before the policy
merges, an operator must set the repository-scoped value to canonical lowercase
`false` and read it back. After bootstrap, eventual activation requires a
verified canonical lowercase `true` readback. Absence, inheritance, or a
skipped-success workflow does not prove safe activation, mirroring, bootstrap,
or downstream CI.

Automation bootstrap remains a separate human gate for the restricted identity,
token, environment, branch allowlist, protection, and final activation readback.
A one-commit operator-mediated transition is only a conditional exception under
a later independently reviewed brief bound to one eligible GitHub SHA, one
task-owned Forgejo source branch, and one protected fast-forward-only PR. It
does not authorize direct `master` pushes or steady-state operator writes.

## Historical Forgejo CI runner

Exact-head GitHub CI is the canonical merge and release gate under Kinocut's
GitHub-primary policy. GitHub #499 records the proposal and transition context.
Forgejo CI is supplemental after the downstream sync is verified. The incident
record below is retained as history and must not be used to justify an independent
Forgejo merge.

CI runner (`colima-ci-runner`, id=15) runs inside the Colima VM via
forgejo-runner v13.0.0 with systemd. Combined status on `5b1936e`
(2026-08-19, CI-restore tip) is **success**, including `lint-checkout`. The 2026-08-19
invisible ~80s lint hole (virtiofs checkout + `claims-live` on `light`
starving apt/curl) is closed: runner home is VM-local
`/mnt/lima-colima/forgejo-runner`; `claims-live.yml` runs on `heavy`.
See [CI_RUNNER_TOPOLOGY.md](CI_RUNNER_TOPOLOGY.md) (**Agent land recipe**: idle
restart → ~90s warm → empty-commit retrigger) and
ops closeout 2026-08-19 (removed 2026-10-11; see git history).

The Actions API still does not expose step-level logs. If a future job is
red without statuses, read
`https://git.kyanitelabs.tech/KyaniteLabs/kinocut/actions` in the web UI.
Do not raise `timeout-minutes` to paper over a missing `lint-checkout`.

PR **#405** retrigger (`16a083e`, run 929): lint **Failing after 1m21s**, no
`lint-checkout`; tests skipped. Operator hypothesis “gpu-host is busy” is a
**busy-host** guess. Live runner list for this repo is only `colima-ci-runner`
(id=15, labels `light`+`heavy`+`arm64-heavy`, status idle at the 2026-08-19
probe). `gpu-host-ci` is not registered here. Same ~80s signature as Colima
capacity-2 / virtiofs starvation. Do not merge #405 red. See
[CI_RUNNER_TOPOLOGY.md](CI_RUNNER_TOPOLOGY.md).

## Product site

Current maintenance publication (2026-10-24): PyPI/npm, GitHub release and the official MCP Registry report **1.16.4**; compatibility shim **1.6.19** pins it. Previous checkpoint (2026-10-05): PyPI/npm and GitHub release report **1.16.1**; compatibility shim **1.6.16** pins it. The initial publication gate read MCP Registry 1.16.1; later reads timed out. Website 1.16.1 source is prepared, not deployed. The dated checkpoint below remains historical.

Official package/release providers report 1.16.0 (verified 2026-10-02). On 2026-10-05, the live [product site](https://kinocut.dev/) showed 1.16.0, 203 MCP tools and 177 CLI commands; installation and benchmark pages responded successfully and the showcase download was available. Website and product-repository social images matched the approved exports. The earlier DNS and social-upload blockers are superseded. Final owner acceptance, fleet rollout and human/model acceptance remain separate. Forgejo issue tracking is excluded; the website repository retains its separately recorded Forgejo source authority.

Historical verification (superseded): on 2026-09-30, live `kinocut.dev` JSON-LD and `llms.txt` reported **1.15.3**, as did PyPI and npm; GitHub latest release reported 1.15.0, and MCP Registry verification returned 403. These observations describe that date, not the current release.

## Adversarial audit residuals

From gpt-5.6-sol audit (2026-08-08). 9 of 11 security findings fixed
(PR #341–#344). **C1/M1 claim-audit (2026-08-12, L0):** closed as **verify-only pass**
on tip — pin-before-connect + peer validation present; preview registry +
`stop_preview`/`atexit` present; SSRF/preview tests green. See
`.omx/state/l0-claim-audit.md`. Reopen only with a **failing case**.

| ID | Severity | File | Status |
|---|---|---|---|
| C1 | CRITICAL | `ai_engine/download.py` | **Claim-audit pass** (2026-08-12) — do not rebuild without fail |
| M1 | MEDIUM | `hyperframes_engine.py` | **Claim-audit pass** (2026-08-12) — do not redesign without fail |

Do not invent third-party directory approvals. Do not re-open #92 as a missing
“first 10” product gate.

## Deferred portfolio rows

See [`docs/status/DEFERRED.md`](status/DEFERRED.md). Growth/marketing rows are
optional ops, not incomplete product phases.

## Owner-approved residuals (parked 2026-08-19)

These need a human for secrets, third-party publish, or upstream — not more
agent coding. Owner approved closing/deferring the GH hygiene rows:

| Item | Why human | Disposition |
| --- | --- | --- |
| Renovate host tokens | Superseded Forgejo-primary setup | Do not provision for Kinocut; GitHub Dependabot is canonical |
| Directories #88 | Third-party directory review / submission | External; do not invent approvals |
| Launch #90 | Marketing publish of drafts | Owner publish gate |
| GH #443 optional X4 dogfood | Physical capture hardware | [Closed as not planned](https://github.com/KyaniteLabs/kinocut/issues/443) on 2026-08-20; not an active release blocker or proof of physical capture acceptance. |
| GH #466 upstream | Previously deferred upstream retirement | [Closed as not planned](https://github.com/KyaniteLabs/kinocut/issues/466) on 2026-08-20; do not retain an active upstream blocker or infer implementation completed. |
| GH #461 parent hygiene | Tracker close after child lands | **Closed** after #414 land |
| skills-agent 0b / DNS | DNS spend / Free-zone skill | Owner only |
| PW dirty push | Owner-owned dirty tree | Do not touch |

Do not invent tokens, force-merge red CI, restart `forgejo-runner` mid-job, or
land normal changes directly on Forgejo. Use a reviewed GitHub PR with exact-head
GitHub CI, and do not claim GitHub-to-Forgejo downstream sync completion before its live gate passes.
