# Install matrix

**Published package:** see [`public_claims.json`](public_claims.json) (`published_version`).  
**Prerequisite:** [FFmpeg](https://ffmpeg.org/) on `PATH`.

## OS package managers

| OS | FFmpeg |
| --- | --- |
| macOS | `brew install ffmpeg` |
| Ubuntu/Debian | `sudo apt install ffmpeg` |
| Windows | Install a build with `ffmpeg` on PATH (e.g. winget/chocolatey/scoop or official builds) |

## Kinocut package

| Goal | Command |
| --- | --- |
| Stable publish | `pip install kinocut==2.0.1` |
| Upgrade | `pip install -U kinocut==2.0.1` |
| From former name | `pip install -U "mcp-video==1.6.22"` (shim → current Kinocut) |
| Editable clone | `pip install -e .` from repo root |
| No global install | `uvx --from kinocut==2.0.1 kino doctor` |

## Verify (doctor-first)

```bash
kino doctor
# or
kino doctor --json
```

**Pass:** `summary.required_ok == true` (or text status without missing required items).  
Optional AI extras can be missing for core editing.

Then prove plumbing:

```bash
python scripts/golden_path.py   # from a clone
```

## MCP hosts

### Claude Code

```bash
claude mcp add kinocut -- uvx --from kinocut==2.0.1 kino --mcp
```

### Cursor / generic stdio JSON

```json
{
  "mcpServers": {
    "kinocut": {
      "command": "uvx",
      "args": ["--from", "kinocut==2.0.1", "kino", "--mcp"]
    }
  }
}
```

Same shape works for other MCP clients that launch a local stdio server.

### Claude Desktop MCPB (staged)

Local package under `mcpb/` — launches an existing Python env with Kinocut; still needs FFmpeg.  
Native self-contained bundles are **not** published yet. See [MCPB.md](MCPB.md).

## Optional extras

| You want | Install | Notes |
| --- | --- | --- |
| Whisper transcription | `pip install "kinocut[transcribe]==2.0.1"` | openai-whisper + torch; large |
| Stem separation | `pip install "kinocut[stems]==2.0.1"` | demucs + torch; large |
| AI upscale | `pip install "kinocut[upscale]==2.0.1"` | Real-ESRGAN; Python 3.11 or 3.12 only |
| Product/object cutouts | `pip install "kinocut[object-matte]==2.0.1"` | ONNX Runtime; downloads ~1 GB of pinned weights on first use |
| Scene and duplicate detection | `pip install "kinocut[ai-scene]==2.0.1"` | imagehash + Pillow |
| Image analysis | `pip install "kinocut[image]==2.0.1"` | Pillow, numpy, scikit-learn |
| Image analysis with Claude descriptions | `pip install "kinocut[image-ai]==2.0.1"` | adds the Anthropic SDK; needs explicit configuration |
| Python client image helpers | `pip install "kinocut[client]==2.0.1"` | Pillow |
| Procedural audio | `pip install "kinocut[audio]==2.0.1"` | numpy (`audio-ai` and `audio-midi` are aliases) |
| Audio effects | `pip install "kinocut[audio-enhanced]==2.0.1"` | scipy + soundfile |
| Beat and tempo analysis | `pip install "kinocut[audio-analysis]==2.0.1"` | librosa |
| All audio | `pip install "kinocut[audio-all]==2.0.1"` | `audio-enhanced` + `audio-analysis` |
| Everything AI | `pip install "kinocut[ai]==2.0.1"` | several GB; `all-ai` adds the `audio-all` set |

`hyperframes` is an empty marker extra: Hyperframes itself is a separate Node.js CLI
(see below).

Core golden path **does not** require extras.

## Hyperframes (optional)

Install the Hyperframes CLI and the Node.js version it requires, then put `hyperframes` on
PATH or set `MCP_VIDEO_HYPERFRAMES_COMMAND` to its command. Not required for FFmpeg tools
or the golden path.

## Revideo bridge (optional, since 1.15.2)

The four Revideo surfaces require Node.js 18 or newer, npm, FFmpeg/ffprobe, and
a Chromium-family browser. `revideo-install` runs `npm ci --no-audit --no-fund`
against Kinocut's committed lockfile and may contact the npm registry. Rendering
stays local. If Puppeteer's downloaded browser cannot execute, point
`KINOCUT_REVIDEO_EXECUTABLE_PATH` at a verified local Chrome or Chromium binary.
Caller-provided scene files are trusted executable TypeScript.
Each install or render entry point checks the Node.js floor before npm runs.

## Python client

```python
from kinocut import Client
Client().info("clip.mp4")
```

## Failure recovery

| Symptom | Fix |
| --- | --- |
| `ffmpeg: command not found` | Install FFmpeg; restart shell |
| `kino: command not found` | `pip install kinocut==2.0.1` or use `python -m kinocut` |
| Import errors / old Python | Use Python 3.11+ |
| Doctor missing optional AI | Expected unless you installed extras |
| Hyperframes hang/init | See Hyperframes doctor; skip for core path |
| Golden path fails mid-workflow | Re-run; check disk space; open workflow stderr |

## Related

- [GOLDEN_PATH.md](GOLDEN_PATH.md)
- [faq.md](faq.md)
- [CLI_REFERENCE.md](CLI_REFERENCE.md)
