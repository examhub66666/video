# mcp-video → Kinocut

## What changed

On **2026-07-10**, the project’s public identity became **Kinocut**.

| Surface | Before | After |
| --- | --- | --- |
| Product name | mcp-video | Kinocut |
| Python package | `mcp-video` | `kinocut` (canonical) |
| Import | `mcp_video` | `kinocut` (canonical) |
| CLI | `mcp-video` | `kino` / `kinocut` (+ compat `mcp-video`) |
| Site | GitHub Pages marketing | https://kinocut.dev/ |
| MCP Registry | former identity | `io.github.KyaniteLabs/kinocut` |
| Repo | mcp-video slug | `KyaniteLabs/kinocut` (GitHub redirect from old slug) |

## Compatibility (current on the 1.14.x+ line)

- `pip install mcp-video==1.6.22` still works via the published shim that installs `kinocut==2.0.1`; the rename date and prior release pairs remain historical.
- `mcp_video` imports, `MCP_VIDEO_*` env vars, `~/.mcp-video` data, `mcp-video://` resources, and legacy receipt keys remain supported during the window.
- New integrations should use `kinocut`, `from kinocut import Client`, and `kino`.

## Why rename

The product is a **guardrailed local execution layer for agentic video**, not “MCP” as the brand. Kinocut names the job: cinema (`kino`) + cut, with trust/receipt semantics.

## For directories and roundups

Please list:

- **Name:** Kinocut (formerly mcp-video)
- **Install:** `pip install kinocut==2.0.1`
- **MCP:** `uvx --from kinocut==2.0.1 kino` / registry `tech.kyanitelabs/kinocut`
- **Site:** https://kinocut.dev/
- **Repo:** https://github.com/KyaniteLabs/kinocut

Version and tool counts: [`public_claims.json`](public_claims.json) (do not invent tip counts as a release).

## Related

- [DIRECTORY_REBRAND_STATUS.md](DIRECTORY_REBRAND_STATUS.md)
- [CHANGELOG.md](../CHANGELOG.md) `1.7.0`
