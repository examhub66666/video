"""Default values for Kinocut.

All default constants used across the codebase are centralized here
per AGENTS.md Rule 12.
"""

from __future__ import annotations

# Re-export encoding defaults from limits for backward compatibility
from .limits import DEFAULT_AI_TIMEOUT, DEFAULT_CRF, DEFAULT_FFMPEG_TIMEOUT, DEFAULT_PRESET  # noqa: F401

DEFAULT_OVERWRITE = False

# Quality presets
DEFAULT_QUALITY = "high"
DEFAULT_FORMAT = "mp4"

# Legacy safe subtitle burn style. Applied as force_style to SRT/VTT when the
# caller supplies no style; authored ASS keeps its own styling and receives no
# force_style so its PlayRes/positions are preserved.
DEFAULT_SUBTITLE_STYLE = "FontSize=22,PrimaryColour=&Hffffff&,OutlineColour=&H000000&,Outline=2,Shadow=1"

# Video dimensions
DEFAULT_FPS = 30
DEFAULT_COMPOSITION_WIDTH = 1920
DEFAULT_COMPOSITION_HEIGHT = 1080
DEFAULT_COMPOSITION_FPS = DEFAULT_FPS
DEFAULT_GIF_FPS = 15
DEFAULT_THUMBNAIL_WIDTH = 320
DEFAULT_STORYBOARD_WIDTH = 480
DEFAULT_STORYBOARD_HEIGHT = 270
DEFAULT_VISION_SAMPLE_TIMES = (0.5, 1.0, 2.0)
DEFAULT_SPHERE_FOV = 90.0
DEFAULT_SPHERE_TABLE_PITCH = -35.0
DEFAULT_SPHERE_OUTPUT_WIDTH = 1920
DEFAULT_SPHERE_OUTPUT_HEIGHT = 1080
DEFAULT_SPHERE_VERTICAL_WIDTH = 1080
DEFAULT_SPHERE_VERTICAL_HEIGHT = 1920
DEFAULT_SPHERE_TEMP_CRF = 28
DEFAULT_SPHERE_TEMP_PRESET = "veryfast"
DEFAULT_SPHERE_QC_SECONDS = 8.0
DEFAULT_SPHERE_PIP_MARGIN = 10
DEFAULT_HASH_CACHE_MAX = 64
DEFAULT_INSPECTION_SAMPLE_PERCENTAGES = (0, 25, 50, 75, 95)
DEFAULT_MOTION_STRIP_CELL_WIDTH = 480
DEFAULT_MOTION_STRIP_CELL_HEIGHT = 270
DEFAULT_INSPECTION_IMAGE_QUALITY = 2
DEFAULT_INSPECTION_PREVIEW_MAX_SECONDS = 30.0
DEFAULT_INSPECTION_PREVIEW_WIDTH = 640
DEFAULT_INSPECTION_PREVIEW_CRF = 28
DEFAULT_INSPECTION_PREVIEW_PRESET = "veryfast"
DEFAULT_REFRAME_VIDEO_CODEC = "libx264"
DEFAULT_REFRAME_PIXEL_FORMAT = "yuv420p"
DEFAULT_SILENCE_MOV_VIDEO_CODEC = "libx264"
DEFAULT_SILENCE_MOV_AUDIO_CODEC = "aac"
DEFAULT_SILENCE_MOV_PIXEL_FORMAT = "yuv420p"
DEFAULT_SILENCE_DURATION_TOLERANCE_SECONDS = 0.15
DEFAULT_GOLDEN_RENDER_SSIM_THRESHOLD = 0.98
DEFAULT_COMPOSITOR_ALPHA_MODE = "straight"
DEFAULT_COMPOSITOR_NOISE_INTENSITY = 0.05
DEFAULT_COMPOSITOR_NOISE_MODE = "film"
DEFAULT_COMPOSITOR_NOISE_ANIMATED = False
DEFAULT_TEMPORAL_BLACK_LUMA_MAX = 8.0
DEFAULT_TEMPORAL_FROZEN_DIFFERENCE_MAX = 0.5
DEFAULT_TEMPORAL_BROKEN_LOOP_DIFFERENCE_MIN = 12.0
DEFAULT_TEMPORAL_TEXT_DRIFT_DIFFERENCE_MIN = 15.0
DEFAULT_TEMPORAL_LATE_FRAME_GAP_MULTIPLIER = 2.0
DEFAULT_TEMPORAL_ANALYSIS_WIDTH = 16
DEFAULT_TEMPORAL_ANALYSIS_HEIGHT = 16

# Deterministic onboarding acceptance fixture.
DEFAULT_ONBOARDING_FIXTURE_WIDTH = 1080
DEFAULT_ONBOARDING_FIXTURE_HEIGHT = 1920
DEFAULT_ONBOARDING_FIXTURE_FRAME_RATE = 30
DEFAULT_ONBOARDING_FIXTURE_DURATION_SECONDS = 6.0
DEFAULT_ONBOARDING_FIXTURE_SINE_FREQUENCY_HZ = 440
DEFAULT_ONBOARDING_FIXTURE_SAMPLE_RATE_HZ = 48000
DEFAULT_ONBOARDING_FIXTURE_AUDIO_VOLUME = 1.95
DEFAULT_ONBOARDING_FIXTURE_EQ_CONTRAST = 0.75
DEFAULT_ONBOARDING_FIXTURE_EQ_BRIGHTNESS = 0.02
DEFAULT_ONBOARDING_FIXTURE_EQ_SATURATION = 1.05
DEFAULT_ONBOARDING_FIXTURE_STABLE_REGION_START_ROW = DEFAULT_ONBOARDING_FIXTURE_HEIGHT * 3 // 5
DEFAULT_ONBOARDING_FIXTURE_STABLE_REGION_HEIGHT = (
    DEFAULT_ONBOARDING_FIXTURE_HEIGHT - DEFAULT_ONBOARDING_FIXTURE_STABLE_REGION_START_ROW
)
DEFAULT_ONBOARDING_FIXTURE_STABLE_REGION_COLOR = "0x808080"
DEFAULT_ONBOARDING_FIXTURE_VIDEO_CODEC = "libx264"
DEFAULT_ONBOARDING_FIXTURE_PIXEL_FORMAT = "yuv420p"
DEFAULT_ONBOARDING_FIXTURE_AUDIO_CODEC = "aac"

# Audio defaults
DEFAULT_SAMPLE_RATE = 44100
DEFAULT_CHANNELS = 1
DEFAULT_AUDIO_CHANNELS = 2
DEFAULT_AUDIO_VOLUME = 0.5
# FFmpeg afftdn default; higher floors can remove voiced harmonics.
DEFAULT_NOISE_REDUCTION_FLOOR_DB = -50
# One output frame per input frame prevents video zoompan from expanding time.
DEFAULT_KEN_BURNS_FRAME_DURATION = 1
DEFAULT_LUFS_TARGET = -16.0
DEFAULT_LRA_TARGET = 11.0
DEFAULT_AUDIO_BITRATE = "128k"
DEFAULT_AUDIO_NORMALIZE_TRUE_PEAK_DBTP = -1.5
DEFAULT_AUDIO_NORMALIZE_BITRATE = "192k"
AUDIO_NORMALIZE_OUTPUT_CODECS = {
    ".wav": "pcm_s16le",
    ".m4a": "aac",
    ".aac": "aac",
    ".mp3": "libmp3lame",
    ".flac": "flac",
    ".ogg": "libvorbis",
    ".opus": "libopus",
    ".aiff": "pcm_s16be",
    ".aif": "pcm_s16be",
    ".mp4": "aac",
    ".mov": "aac",
    ".mkv": "aac",
}
AUDIO_NORMALIZE_VIDEO_CONTAINERS = frozenset({".mp4", ".mov", ".mkv"})
DEFAULT_PROCEDURAL_AUDIO_BED_WARNING_SECONDS = 10.0

# Audio-bed defaults (field-proven sidechain ducking + loudness normalization).
# The governed one-shot bed composes these with the existing duck_audio engine.
DEFAULT_AUDIO_BED_DUCK_THRESHOLD = 0.02
DEFAULT_AUDIO_BED_DUCK_RATIO = 5.0
DEFAULT_AUDIO_BED_DUCK_ATTACK_MS = 25.0
DEFAULT_AUDIO_BED_DUCK_RELEASE_MS = 450.0
DEFAULT_AUDIO_BED_LOOP_CROSSFADE = 1.5
DEFAULT_AUDIO_BED_FADE_IN = 0.0
DEFAULT_AUDIO_BED_FADE_OUT = 2.2
DEFAULT_AUDIO_BED_TARGET_LUFS = -16.0
DEFAULT_AUDIO_BED_DURATION_TOLERANCE_SECONDS = 0.35
DEFAULT_AUDIO_BED_MUSIC_VOLUME = 1.0
DEFAULT_AUDIO_BED_TRUE_PEAK_DBTP = -1.5

DEFAULT_AUDIO_BED_LOOP_MAX_PLAYS = 100

# Text overlay defaults
DEFAULT_FONT_SIZE = 48
DEFAULT_TEXT_COLOR = "white"
DEFAULT_TEXT_POSITION = "top-center"
DEFAULT_SAFE_SUBTITLE_FONT_SIZE = 24
DEFAULT_SUBTITLE_MAX_CHARS_PER_LINE = 42
DEFAULT_SUBTITLE_MAX_LINES = 3

# Agent/release guardrail defaults
MIN_FFMPEG_VERSION_HARD = 5
MIN_FFMPEG_VERSION = 6
MIN_PYTHON_VERSION = (3, 11)
DEFAULT_GLOW_MAX_SAFE_INTENSITY = 0.25
DEFAULT_QUALITY_GATE_SCORE = 80.0
# Quality heuristics use an 8-bit limited-range signal domain, not HDR luminance.
DEFAULT_QUALITY_GRAYSCALE_INPUT_FILTER = "setparams=range=full"
# Motion converts gray to YUV before differencing so conversion cannot add a
# limited-range black offset to an already-computed difference image.
DEFAULT_QUALITY_MOTION_PIXEL_FORMATS = "yuv444p|yuvj444p|yuv444p9le|yuv444p10le|yuv444p12le|yuv444p14le|yuv444p16le"
DEFAULT_QUALITY_MOTION_FILTER = (
    f"format=pix_fmts={DEFAULT_QUALITY_MOTION_PIXEL_FORMATS},tblend=all_mode=difference,signalstats"
)
DEFAULT_QUALITY_SIGNALSTATS_FALLBACK_PIXEL_FORMATS = "yuv420p|yuv422p|yuv444p|yuv440p|yuv411p|yuv410p"
# Bound retained signal measurements on long-lived quality guardrail instances.
QUALITY_SIGNALSTATS_CACHE_MAX_ENTRIES = 32
DEFAULT_C2PA_TIMEOUT = 120

# Transition defaults
DEFAULT_TRANSITION_DURATION = 1.0

# Body-swap defaults
DEFAULT_BODY_SWAP_DURATION_TOLERANCE_SECONDS = 0.1
DEFAULT_BODY_SWAP_HASH_BUFFER_BYTES = 1024 * 1024

# AI-video salvage verification
DEFAULT_SALVAGE_DURATION_TOLERANCE_SECONDS = 0.12
DEFAULT_SALVAGE_FREEZE_CODEC = "ffv1"
DEFAULT_SALVAGE_FREEZE_PIXEL_FORMAT = "yuv420p"

# Subtitle QA defaults — shared source of truth per AGENTS.md Rule 12.
# Tunable thresholds plus the shipped design-guardrail heuristic factors used
# to estimate subtitle bounding boxes at full display resolution.
DEFAULT_SUBTITLE_QA_READING_SPEED_CPS = 25.0
DEFAULT_SUBTITLE_QA_GAP_SECONDS_THRESHOLD = 3.0
DEFAULT_SUBTITLE_QA_CHAR_WIDTH_FACTOR = 0.6
DEFAULT_SUBTITLE_QA_LINE_HEIGHT_FACTOR = 1.2
# Deterministic detectors produce certain findings — this confidence value is
# the semantic representation of that certainty, not a tunable threshold.
DEFAULT_SUBTITLE_QA_DETECTOR_CONFIDENCE = 1.0

# Grid/layout defaults
DEFAULT_GRID_CELL_WIDTH = 640
DEFAULT_GRID_CELL_HEIGHT = 480

# NIMA aesthetic scoring defaults
DEFAULT_NIMA_CANDIDATES = 8
DEFAULT_NIMA_MIN_DURATION = 3.0

# Shared hashing/serialization chunk size for streaming SHA-256 over files.
# Centralized so every caller hashes at the same I/O granularity.
DEFAULT_HASH_CHUNK_BYTES = 1 << 20  # 1 MiB

# Still/plate editor — shared gain clamps and cohesion gate thresholds.
STILL_MATCH_MIN_GAIN = 0.35
STILL_MATCH_MAX_GAIN = 2.5
STILL_GATE_MAX_LUMA_SPREAD = 0.18
STILL_GATE_MAX_SHADOW_GREEN_CYAN = 0.22
# Shadow band for green/cyan fog detection (linear light after sRGB-ish load).
STILL_SHADOW_LUMA_MAX = 0.18
# Near-black / near-white bands for signal-mode extrema preservation.
STILL_NEAR_BLACK_MAX = 0.05
STILL_NEAR_WHITE_MIN = 0.95


# Graphics canvas defaults (applied when the caller omits the field).
DEFAULT_GRAPHICS_CANVAS_FPS = 24.0
DEFAULT_GRAPHICS_CANVAS_DURATION = 2.0
DEFAULT_GRAPHICS_CANVAS_BACKGROUND = "#000000"

# Graphics layer defaults (applied when the caller omits the field).
DEFAULT_GRAPHICS_LAYER_COLOR = "#FFFFFF"
DEFAULT_GRAPHICS_LAYER_OPACITY = 1.0
# Default graphics-layer position stored as immutable coordinate constants so
# the per-instance dict factory in GraphicsLayer cannot share mutable state
# across instances (frozen models don't deep-freeze mutable containers).
DEFAULT_GRAPHICS_LAYER_POSITION_X = 0.0
DEFAULT_GRAPHICS_LAYER_POSITION_Y = 0.0

# Remove-background dispatcher. Default is people (Hyperframes).
# birefnet-general is the product/object path (Kinocut ONNX extra).
DEFAULT_REMOVE_BACKGROUND_MODEL = "u2net_human_seg"
DEFAULT_REMOVE_BACKGROUND_MASK_INTERVAL = 1
DEFAULT_OBJECT_MATTE_TIMEOUT = DEFAULT_AI_TIMEOUT
DEFAULT_OBJECT_MATTE_MEDIAN_WINDOW = 3
DEFAULT_EQUIPMENT_SUBJECT_INTERSECTION = 0.02
OBJECT_MATTE_IMAGENET_MEAN = (0.485, 0.456, 0.406)
OBJECT_MATTE_IMAGENET_STD = (0.229, 0.224, 0.225)
OBJECT_MATTE_STILL_SUFFIXES = frozenset({".png", ".jpg", ".jpeg", ".webp", ".tif", ".tiff"})


# Revideo bridge (Sinter x Kino integration, liminal #999). The vendored
# template under kinocut/revideo_template pins @revideo 0.11.0 (MIT) via a
# committed package-lock.json; installs go through `npm ci` only.
DEFAULT_REVIDEO_FPS = 30.0
DEFAULT_REVIDEO_WIDTH = 1920
DEFAULT_REVIDEO_HEIGHT = 1080
DEFAULT_REVIDEO_FRAMES = 60
DEFAULT_REVIDEO_WORKERS = 2
DEFAULT_REVIDEO_SEED = 1
DEFAULT_REVIDEO_OUT_FILE = "video.mp4"
DEFAULT_REVIDEO_INSTALL_TIMEOUT = 300
DEFAULT_REVIDEO_RENDER_TIMEOUT = 900
DEFAULT_RENDER_STOP_TIMEOUT = 5.0
DEFAULT_FFMPEG_PROGRESS_READER_JOIN_TIMEOUT = 5.0
DEFAULT_RENDER_STOP_POLL_INTERVAL = 0.02
# Extra wall time the POSIX orphan watchdog may add to an ordinary command
# spawn (one extra interpreter for process_guardian.py). Measured median extra
# cost is ~33ms on Linux and ~89ms on macOS GitHub runners; keep the bound
# above both so CI stays honest without hiding a stuck guardian.
DEFAULT_PROCESS_GUARDIAN_SPAWN_BUDGET_MS = 150.0
# macOS may refuse to exec puppeteer's downloaded chrome-headless-shell
# (protected com.apple.provenance xattr -> spawn ECANCELED); the engine
# forwards this env var so the bridge can use a system Chrome instead.
REVIDEO_EXECUTABLE_PATH_ENV = "KINOCUT_REVIDEO_EXECUTABLE_PATH"

# Sinter winners-bundle envelope (liminal #999, option A, provisional v0.1 —
# the frozen-at-export contract Kino ingests; judges is deliberately absent
# pending the envelope-pin answer on #999).
REVIDEO_WINNERS_SCHEMA_VERSION = "sinter.winners/0.1"

# Finite dBFS convention and silence boundary for audio waveform analysis.
DEFAULT_WAVEFORM_LEVEL_FLOOR = -120.0
DEFAULT_WAVEFORM_SILENCE_THRESHOLD = -50.0
DEFAULT_WAVEFORM_FRAME_SAMPLES = 1024

# One-pass audio mixing and standalone sidechain ducking.
DEFAULT_AUDIO_MIX_BITRATE = "256k"
DEFAULT_AUDIO_MIX_SAMPLE_RATE = 48000
DEFAULT_AUDIO_MIX_TRACK_VOLUME = 1.0
DEFAULT_DUCK_MUSIC_VOLUME = 0.6
DEFAULT_DUCK_THRESHOLD = 0.05
DEFAULT_DUCK_RATIO = 8.0
DEFAULT_DUCK_ATTACK_MS = 20.0
DEFAULT_DUCK_RELEASE_MS = 300.0

# Chronological image-change QA is advisory; these are luma-change proxies,
# not optical flow, semantic coherence, or delivery approval thresholds.
DEFAULT_MOTION_COHERENCE_WINDOW_SECONDS = 1.0
DEFAULT_MOTION_COHERENCE_LURCH_RATIO = 4.0
DEFAULT_MOTION_COHERENCE_LURCH_DELTA = 60.0
DEFAULT_MOTION_COHERENCE_HIGH_RATE = 120.0
DEFAULT_MOTION_COHERENCE_CALM_RATE = 1.0
DEFAULT_MOTION_COHERENCE_SUSTAINED_WINDOWS = 2
DEFAULT_MOTION_COHERENCE_TRANSITION_DIFFERENCE = 40.0

# Duplicate recognition across overlapping chunks must refer to the same
# observed event, not merely repeat the same token somewhere in the overlap.
DEFAULT_LONGFORM_DUPLICATE_TIME_TOLERANCE_SECONDS = 0.25

# Executed semantic vision provider defaults.
DEFAULT_VISION_MODE = "off"
DEFAULT_VISION_MODEL = "claude-sonnet-4-20250514"
DEFAULT_VISION_BASE_URL = "https://api.anthropic.com"
DEFAULT_PRODUCT_DESCRIPTION_MAX_TOKENS = 300
ENV_PRODUCT_DESCRIPTION_MAX_TOKENS = "KINOCUT_PRODUCT_DESCRIPTION_MAX_TOKENS"
ENV_VISION_MAX_TOKENS = "KINOCUT_VISION_MAX_TOKENS"
MIN_VISION_MAX_TOKENS = 16
MAX_VISION_MAX_TOKENS = 8192
DEFAULT_VISION_PROVIDER_TIMEOUT = 60
DEFAULT_VISION_PROVIDER_MAX_TOKENS = 1024
DEFAULT_VISION_MAX_FRAME_WIDTH = 1280
DEFAULT_REVIDEO_TELEMETRY = False
DEFAULT_HYPERFRAMES_TELEMETRY = False
DEFAULT_HYPERFRAMES_VERSION_TIMEOUT = 10

# Google Fonts network policy: socket timeout plus total elapsed deadline.
DEFAULT_FONT_DOWNLOAD_TIMEOUT = 20
DEFAULT_FONT_DOWNLOAD_DEADLINE = 60

# Preserve AI scene sampling and hash defaults under explicit producer bounds.
DEFAULT_AI_SCENE_FRAME_INTERVAL = 0.5
DEFAULT_AI_SCENE_JPEG_QUALITY = 2
DEFAULT_AI_SCENE_HASH_THRESHOLD = 10


def token_budget(env_name: str, default: int) -> int:
    """Operator-set output-token budget; reasoning models need more than the defaults.

    Reads env_name as an integer between MIN_VISION_MAX_TOKENS and
    MAX_VISION_MAX_TOKENS. An unset, malformed or out-of-range value falls
    back to default rather than failing a request.
    """
    import os

    raw = os.environ.get(env_name, "").strip()
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if MIN_VISION_MAX_TOKENS <= value <= MAX_VISION_MAX_TOKENS else default
