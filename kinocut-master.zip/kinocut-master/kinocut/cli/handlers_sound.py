"""CLI handlers for the thin kinocut_sound S12 public join."""

from __future__ import annotations

from typing import Any

from ..validation_errors import reason
from ..json_artifacts import load_json_artifact, parse_json_artifact
from ..limits import MAX_CLI_JSON_ARTIFACT_BYTES
from .runner import CommandRunner, _out


def _invoke(name: str, **kwargs: Any) -> dict[str, Any]:
    from kinocut.sound_joins.loudness import invoke_sound_operation

    return invoke_sound_operation(name, **kwargs)


def _load_plan_json(raw: str | None) -> dict[str, Any] | None:
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None
    if text.startswith("{"):
        return parse_json_artifact(raw, max_bytes=MAX_CLI_JSON_ARTIFACT_BYTES)
    return load_json_artifact(text, max_bytes=MAX_CLI_JSON_ARTIFACT_BYTES)


def _loudness(a, j):
    from kinocut_sound._errors import SoundContractError
    from kinocut_sound.public.mix_files import load_request_file
    from kinocut.errors import MCPVideoError

    try:
        if a.request_json is None and a.project_root is None:
            result = _invoke("sound-qa-loudness")
        else:
            raw = a.request_json
            request = raw if raw is None or raw.lstrip().startswith("{") else load_request_file(raw)
            result = _invoke("sound-qa-loudness", request=request, project_root=a.project_root)
        _out(result, j)
    except SoundContractError as exc:
        raise MCPVideoError(reason(exc), error_type=exc.error_type, code=exc.code) from exc


def _master(a, j):
    from kinocut_sound._errors import SoundContractError
    from kinocut_sound.public.mix_files import load_request_file
    from kinocut.errors import MCPVideoError

    try:
        raw = a.request_json
        request = raw if raw.lstrip().startswith("{") else load_request_file(raw)
        _out(_invoke("sound-master-render", request=request, project_root=a.project_root), j)
    except SoundContractError as exc:
        raise MCPVideoError(reason(exc), error_type=exc.error_type, code=exc.code) from exc


def handle_sound_commands(args: Any, *, use_json: bool) -> bool:
    runner = CommandRunner(args, use_json)

    def _caps(_a, j):
        _out(_invoke("sound-capabilities"), j)

    def _plan(a, j):
        from kinocut_sound._errors import SoundContractError
        from kinocut.errors import MCPVideoError

        plan = _load_plan_json(getattr(a, "plan_json", None))
        try:
            result = _invoke("sound-plan-validate", plan=plan)
        except SoundContractError as exc:
            raise MCPVideoError(
                str(exc),
                error_type=exc.error_type,
                code=exc.code,
                suggested_action=exc.suggested_action,
                details=exc.details,
            ) from exc
        _out(result, j)

    def _voice(a, j):
        from kinocut_sound._errors import SoundContractError
        from kinocut_sound.public.mix_files import load_request_file
        from kinocut.errors import MCPVideoError

        try:
            if a.request_json is None and a.project_root is None:
                result = _invoke("sound-voice-batch", plan=_load_plan_json(a.plan_json))
            else:
                if a.plan_json is not None:
                    raise MCPVideoError(
                        "caption request and synthetic plan modes conflict", error_type="validation_error"
                    )
                raw = a.request_json
                request = raw if raw is None or raw.lstrip().startswith("{") else load_request_file(raw)
                result = _invoke("sound-voice-batch", request=request, project_root=a.project_root)
            _out(result, j)
        except SoundContractError as exc:
            raise MCPVideoError(reason(exc), error_type=exc.error_type, code=exc.code) from exc

    def _mix(a, j):
        from kinocut_sound._errors import SoundContractError
        from kinocut_sound.public.mix_files import load_request_file
        from kinocut.errors import MCPVideoError

        raw, root = a.request_json, a.project_root
        try:
            if raw is None and root is None:
                result = _invoke("sound-mix-render")
            else:
                request = raw if raw is None or raw.lstrip().startswith("{") else load_request_file(raw)
                result = _invoke("sound-mix-render", request=request, project_root=root)
            _out(result, j)
        except SoundContractError as exc:
            raise MCPVideoError(reason(exc), error_type=exc.error_type, code=exc.code) from exc

    def _asr(a, j):
        from kinocut_sound._errors import SoundContractError
        from kinocut_sound.public.mix_files import load_request_file
        from kinocut.errors import MCPVideoError

        try:
            raw = a.request_json
            request = raw if raw.lstrip().startswith("{") else load_request_file(raw)
            result = _invoke("sound-qa-asr", request=request, project_root=a.project_root)
            _out(result, j)
        except SoundContractError as exc:
            raise MCPVideoError(reason(exc), error_type=exc.error_type, code=exc.code) from exc

    runner.register("sound-capabilities", _caps)
    runner.register("sound-plan-validate", _plan)
    runner.register("sound-voice-batch", _voice)
    runner.register("sound-mix-render", _mix)
    runner.register("sound-master-render", _master)
    runner.register("sound-qa-loudness", _loudness)
    runner.register("sound-qa-asr", _asr)
    return runner.dispatch()
