"""Rich renderables for quality verdicts and human release checkpoints."""

from typing import Any

from rich.markup import escape
from rich.panel import Panel
from rich.table import Table


def quality_report_renderables(data: Any) -> tuple[Table, str]:
    if not isinstance(data, dict):
        data = {}
    profile = data.get("profile")
    profile_name = profile.get("name") if isinstance(profile, dict) else None
    title = f"Quality Check (profile: {escape(str(profile_name))})" if profile_name else "Quality Check"
    table = Table(title=title)
    table.add_column("Check", style="bold cyan")
    table.add_column("Status")
    table.add_column("Value")
    checks = data.get("checks", {})
    if isinstance(checks, dict):
        for check, info in checks.items():
            status = "[green]PASS[/green]" if info.get("passed") else "[red]FAIL[/red]"
            table.add_row(check, status, str(info.get("value", "")))
    elif isinstance(checks, list):
        for info in checks:
            if not isinstance(info, dict):
                continue
            status = "[green]PASS[/green]" if info.get("passed") else "[red]FAIL[/red]"
            score = info.get("score")
            message = info.get("message")
            value_parts = []
            if score is not None:
                try:
                    value_parts.append(f"{float(score):.1f}")
                except (TypeError, ValueError):
                    value_parts.append(escape(str(score)))
            if message:
                value_parts.append(escape(str(message)))
            table.add_row(str(info.get("name", "unknown")), status, " — ".join(value_parts))
    baseline = data.get("profile_baseline")
    if isinstance(baseline, dict) and baseline.get("overall_score") is not None:
        table.caption = escape(
            f"Under the {baseline.get('profile', 'default')} profile this cut scores {baseline['overall_score']}."
        )
    if "gate_passed" in data:
        return table, f"[bold]{gate_verdict_line(data)}[/bold]"
    overall_passed = data.get("all_passed", data.get("passed", False))
    overall = "[green]PASS[/green]" if overall_passed else "[red]FAIL[/red]"
    return table, f"[bold]Overall: {overall}[/bold]"


def gate_verdict_line(data: dict[str, Any]) -> str:
    """Describe a score gate and the per-check outcome as separate verdicts."""
    score = data.get("overall_score")
    min_score = data.get("min_score")
    gate = "[green]Gate PASSED[/green]" if data.get("gate_passed") else "[red]Gate FAILED[/red]"
    if score is not None and min_score is not None:
        op = "≥" if score >= min_score else "<"
        gate += f" at score {score} {op} {min_score}"
    failed = [str(name) for name in data.get("failed_checks") or []]
    if failed:
        noun = "check" if len(failed) == 1 else "checks"
        return f"{gate}; [yellow]{len(failed)} {noun} below target:[/yellow] {escape(', '.join(failed))}"
    return f"{gate}; all checks passed"


def release_checkpoint_renderable(data: Any) -> Panel | str:
    if not isinstance(data, dict):
        data = {}
    if data.get("error"):
        message = data["error"].get("message", "release checkpoint failed")
        return f"[bold red]RELEASE CHECKPOINT FAILED:[/bold red] {escape(str(message))}"
    quality = data.get("quality") or {}
    score = quality.get("overall_score")
    lines = []
    if score is not None:
        lines.append(f"[bold green]Quality score:[/bold green] {score}")
    if isinstance(quality, dict) and "gate_passed" in quality:
        lines.append(gate_verdict_line(quality))
    if data.get("thumbnail"):
        lines.append(f"[bold green]Thumbnail:[/bold green] {data['thumbnail']}")
    storyboard = data.get("storyboard") or {}
    if isinstance(storyboard, dict) and storyboard.get("output_path"):
        lines.append(
            f"[bold green]Storyboard:[/bold green] {storyboard['output_path']} ({storyboard.get('count', '?')} frames)"
        )
    if data.get("review_required"):
        lines.append("[bold yellow]Review required:[/bold yellow] inspect the artifacts before publishing.")
    if data.get("instructions"):
        lines.append(escape(str(data["instructions"])))
    return Panel("\n".join(lines), title="Release Checkpoint", border_style="green")


def design_quality_panel(data: Any) -> Panel:
    score = data.get("overall_score", "N/A")
    issues = data.get("issues", [])
    warnings = data.get("warnings", [])
    lines = [f"[bold green]Score:[/bold green] {score}"]
    if issues:
        lines.append(f"[red]Issues ({len(issues)}):[/red]")
        for issue in issues[:5]:
            lines.append(f"  - {issue}")
    if warnings:
        lines.append(f"[yellow]Warnings ({len(warnings)}):[/yellow]")
        for w in warnings[:5]:
            lines.append(f"  - {w}")
    return Panel("\n".join(lines), title="Design Quality", border_style="green")


def format_cli_error(
    e: Exception,
    err_console: Any,
    logger: Any,
    command: str | None = None,
    arguments: dict[str, Any] | None = None,
) -> None:
    """Display an error in a styled panel."""
    from ..errors import MCPVideoError, retry_context, retry_message

    if isinstance(e, MCPVideoError):
        try:
            with retry_context(command or "kino", arguments or {}):
                data = e.to_dict()
        except Exception as exc:
            logger.debug("MCPVideoError.to_dict() failed in CLI formatting: %s", exc)
            data = {"message": retry_message(str(e), getattr(e, "code", "unknown"))}
        msg = data.get("message", retry_message(str(e), getattr(e, "code", "unknown")))
        code = data.get("code", "")
        action = data.get("suggested_action", {})
        # Exception text is data, not Rich markup: escape it so tokens like
        # ``[transcribe]`` in an install hint survive to the visible panel
        # instead of being parsed as style tags.
        lines = [f"[bold red]{escape(str(msg))}[/bold red]"]
        if code:
            lines.append(f"[dim]Code: {escape(str(code))}[/dim]")
        if isinstance(action, dict) and action.get("description"):
            lines.append(f"\n[yellow]Suggested fix:[/yellow] {escape(str(action['description']))}")
        err_console.print(Panel("\n".join(lines), border_style="red", title="Error"))
    else:
        err_console.print(
            Panel(
                f"[bold red]{escape(retry_message(str(e), 'unknown'))}[/bold red]",
                border_style="red",
                title="Error",
            )
        )
