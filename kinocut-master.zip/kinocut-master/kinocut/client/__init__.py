"""Kinocut Python client: a clean API for programmatic video editing."""

from __future__ import annotations

from .estimates import ClientEstimatesMixin
from .base import ClientBase
from .media import ClientMediaMixin
from .effects import ClientEffectsMixin
from .audio import ClientAudioMixin
from .ai import ClientAiMixin
from .hyperframes import ClientHyperframesMixin
from .image import ClientImageMixin
from .quality import ClientQualityMixin
from .meta import ClientMetaMixin
from .rescue import ClientRescueMixin
from .postrescue import ClientPostRescueMixin
from .workflow import ClientWorkflowMixin
from .inspection import ClientInspectionMixin
from .aivideo import ClientAIVideoMixin
from .release import ClientReleaseMixin
from .shorts import ClientShortsMixin
from .sound import ClientSoundMixin
from .sphere import ClientSphereMixin
from .revideo import ClientRevideoMixin


class Client(
    ClientBase,
    ClientEstimatesMixin,
    ClientMediaMixin,
    ClientEffectsMixin,
    ClientAudioMixin,
    ClientAiMixin,
    ClientHyperframesMixin,
    ClientImageMixin,
    ClientQualityMixin,
    ClientMetaMixin,
    ClientWorkflowMixin,
    ClientRescueMixin,
    ClientPostRescueMixin,
    ClientInspectionMixin,
    ClientAIVideoMixin,
    ClientReleaseMixin,
    ClientShortsMixin,
    ClientSoundMixin,
    ClientSphereMixin,
    ClientRevideoMixin,
):
    """mcp-video client for programmatic video editing.

    Usage:
        from mcp_video import Client
        editor = Client()

        result = editor.trim("input.mp4", start="00:00:30", duration="00:00:15")
        print(result.output_path)
    """
