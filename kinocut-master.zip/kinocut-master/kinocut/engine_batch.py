"""Batch operation dispatcher for the FFmpeg engine."""

from __future__ import annotations

import hashlib
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextvars import copy_context
from typing import Any

from .engine_audio_normalize import normalize_audio
from .engine_convert import convert
from .engine_edit import trim
from .engine_fade import fade
from .engine_filters import apply_filter
from .engine_resize import resize
from .engine_speed import speed
from .engine_watermark import watermark
from .errors import MCPVideoError
from .ffmpeg_helpers import _validate_input_path, _validate_output_path
from .models import EditResult
from .validation_errors import rejected_value
from .validation_errors import reason

VALID_BATCH_OPERATIONS = {
    "trim",
    "resize",
    "convert",
    "filter",
    "blur",
    "color_grade",
    "watermark",
    "speed",
    "fade",
    "normalize_audio",
}


def _validate_batch_operation(operation: str) -> None:
    if operation not in VALID_BATCH_OPERATIONS:
        raise MCPVideoError(
            f"Unknown operation '{rejected_value(operation)}'. Valid operations: {sorted(VALID_BATCH_OPERATIONS)}",
            error_type="validation_error",
            code="invalid_operation",
        )


def video_batch(
    inputs: list[str],
    operation: str,
    params: dict[str, Any] | None = None,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Apply the same operation to multiple video files."""
    if not inputs:
        return {
            "success": False,
            "error": {"type": "input_error", "code": "empty_inputs", "message": "No input files provided"},
        }

    params = params or {}
    _validate_batch_operation(operation)
    if output_dir:
        try:
            output_dir = _validate_output_path(output_dir)
        except MCPVideoError as exc:
            if exc.code != "unsafe_path":
                raise
            return {
                "success": False,
                "total": len(inputs),
                "succeeded": 0,
                "failed": len(inputs),
                # The caught text is the caller's own input echoed back; the kind is
                # what a batch result needs. The detail stays in the log.
                "results": [{"input": input_path, "success": False, "error": reason(exc)} for input_path in inputs],
            }

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    def _process_one(input_path: str) -> dict[str, Any]:
        try:
            validated = _validate_input_path(input_path)
            result = _run_batch_operation(validated, operation, params, output_dir)
            return {"input": input_path, "success": True, "output_path": result.output_path}
        except Exception as e:
            logging.warning("Batch operation failed for %s: %s", input_path, e)
            return {"input": input_path, "success": False, "error": reason(e)}

    max_workers = min(len(inputs), os.cpu_count() or 4, 4)
    # Serial fallback for duplicate inputs (same file → same output path → race)
    has_dupes = len(set(inputs)) < len(inputs)
    if has_dupes or max_workers <= 1:
        results = [_process_one(inp) for inp in inputs]
    else:
        indexed: list[dict[str, Any] | None] = [None] * len(inputs)
        idx_map = {inp: i for i, inp in enumerate(inputs)}
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {pool.submit(copy_context().run, _process_one, inp): inp for inp in inputs}
            for future in as_completed(futures):
                orig = futures[future]
                indexed[idx_map[orig]] = future.result()
        results = indexed

    succeeded = sum(1 for r in results if r and r.get("success"))
    failed = len(results) - succeeded

    return {
        "success": failed == 0,
        "total": len(inputs),
        "succeeded": succeeded,
        "failed": failed,
        "results": results,
    }


def _batch_output_name(input_path: str, operation: str, ext: str) -> str:
    """Build a collision-resistant output basename for a batch input.

    Includes a short hash of the absolute parent directory so same-named inputs
    from different folders (dir1/clip.mp4 vs dir2/clip.mp4) don't overwrite
    each other in the shared output directory.
    """
    name = os.path.splitext(os.path.basename(input_path))[0]
    parent = os.path.dirname(os.path.abspath(input_path))
    digest = hashlib.sha1(parent.encode(), usedforsecurity=False).hexdigest()[:8]
    return f"{name}_{operation}_{digest}{ext}"


def _run_batch_operation(
    input_path: str,
    operation: str,
    params: dict[str, Any],
    output_dir: str | None,
) -> EditResult:
    def _batch_output(ext: str | None = None) -> str | None:
        if not output_dir:
            return None
        return os.path.join(output_dir, _batch_output_name(input_path, operation, ext or ".mp4"))

    if operation == "trim":
        return trim(
            input_path,
            start=params.get("start", "0"),
            duration=params.get("duration"),
            end=params.get("end"),
            output_path=_batch_output(),
        )
    if operation == "resize":
        return resize(
            input_path,
            width=params.get("width"),
            height=params.get("height"),
            aspect_ratio=params.get("aspect_ratio"),
            quality=params.get("quality", "high"),
            output_path=_batch_output(),
        )
    if operation == "convert":
        out_ext = f".{params.get('format', 'mp4')}"
        return convert(
            input_path,
            format=params.get("format", "mp4"),
            quality=params.get("quality", "high"),
            output_path=_batch_output(out_ext),
        )
    if operation == "filter":
        return apply_filter(
            input_path,
            filter_type=params.get("filter_type", "blur"),
            params=params.get("filter_params", {}),
            output_path=_batch_output(),
        )
    if operation == "blur":
        return apply_filter(
            input_path, filter_type="blur", params=params.get("filter_params", {}), output_path=_batch_output()
        )
    if operation == "color_grade":
        return apply_filter(
            input_path,
            filter_type="color_preset",
            params={"preset": params.get("preset", "warm")},
            output_path=_batch_output(),
        )
    if operation == "watermark":
        return watermark(
            input_path,
            image_path=params.get("image_path", ""),
            position=params.get("position", "bottom-right"),
            opacity=params.get("opacity", 0.7),
            output_path=_batch_output(),
        )
    if operation == "speed":
        return speed(input_path, factor=params.get("factor", 1.0), output_path=_batch_output())
    if operation == "fade":
        return fade(
            input_path,
            fade_in=params.get("fade_in", 0.5),
            fade_out=params.get("fade_out", 0.5),
            output_path=_batch_output(),
        )
    if operation == "normalize_audio":
        return normalize_audio(input_path, target_lufs=params.get("target_lufs", -16.0), output_path=_batch_output())
    raise MCPVideoError(
        f"Unknown operation '{operation}'. Valid operations: {sorted(VALID_BATCH_OPERATIONS)}",
        error_type="validation_error",
        code="invalid_operation",
    )
