"""C2PA provenance signing provider for final path-based exports."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from enum import StrEnum
from typing import Any

from .defaults import DEFAULT_C2PA_TIMEOUT
from .errors import C2PASigningError, C2PAToolNotFoundError, C2PAVerificationError, MCPVideoError
from .validation_errors import exception_kind
from .ffmpeg_helpers import _atomic_output, _validate_artifact_input_path, _validate_input_path


class SigningStatus(StrEnum):
    """Outcome of C2PA signing. Every failure raises, so a returned receipt is SIGNED."""

    SIGNED = "signed"


_UNTRUSTED_SIGNING_CREDENTIAL_STATUS = "signingCredential.untrusted"
_UNTRUSTED_SIGNING_CREDENTIAL_WARNING = "signing_credential_untrusted"


def sign_export_with_c2pa(
    asset_path: str,
    *,
    manifest_path: str,
    signer_path: str | None = None,
) -> dict[str, Any]:
    """Add and verify a C2PA manifest on an already-rendered final export.

    The c2patool executable is resolved from the KINOCUT_C2PATOOL or
    MCP_VIDEO_C2PATOOL environment variable (falling back to PATH) and is
    never accepted from request input, to prevent arbitrary-executable
    injection via the public tool surface. ``signer_path`` is an internal,
    operator-configured option and must not originate from untrusted input.
    """
    # Signing deliberately replaces this final export after verification. Do
    # not register a new read-only input; existing input aliases stay guarded.
    asset = _validate_input_path(asset_path, record_operation=False)
    manifest = _validate_manifest_path(manifest_path)
    tool = _resolve_c2patool()

    with _atomic_output(asset) as signed_tmp:
        cmd = [tool, asset, "--manifest", manifest, "--output", signed_tmp, "--force"]
        if signer_path:
            cmd.extend(["--signer-path", signer_path])
        _run_c2patool(cmd, "sign")
        if not os.path.isfile(signed_tmp) or os.path.getsize(signed_tmp) == 0:
            raise C2PASigningError("c2patool completed without producing the signed output")
        verification = _verify_signed_asset(tool, signed_tmp)
    return {
        "status": SigningStatus.SIGNED,
        "verified": True,
        "trusted": verification["trusted"],
        "warning_codes": verification["warning_codes"],
    }


def _validate_manifest_path(path: str) -> str:
    if not path.lower().endswith(".json"):
        raise MCPVideoError(
            "c2pa_manifest_path must point to a .json manifest definition file",
            error_type="validation_error",
            code="invalid_c2pa_manifest",
        )
    _validate_artifact_input_path(path)
    if not os.path.isfile(path):
        raise MCPVideoError(
            "C2PA manifest file not found",
            error_type="input_error",
            code="invalid_c2pa_manifest",
        )
    return os.path.realpath(path)


def _resolve_c2patool() -> str:
    candidate = os.environ.get("KINOCUT_C2PATOOL") or os.environ.get("MCP_VIDEO_C2PATOOL") or "c2patool"
    resolved = shutil.which(candidate) if os.path.basename(candidate) == candidate else candidate
    if resolved is None or not os.path.isfile(resolved) or not os.access(resolved, os.X_OK):
        raise C2PAToolNotFoundError()
    return os.path.realpath(resolved)


def _run_c2patool(
    cmd: list[str],
    phase: str,
    *,
    verification: bool = False,
) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(  # noqa: S603
            cmd,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=DEFAULT_C2PA_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        if verification:
            raise C2PAVerificationError(f"{phase} timed out after {DEFAULT_C2PA_TIMEOUT}s") from exc
        raise C2PASigningError(f"{phase} timed out after {DEFAULT_C2PA_TIMEOUT}s", code="c2pa_timeout") from exc
    if result.returncode != 0:
        if verification:
            raise C2PAVerificationError("c2patool verification command failed")
        # The child's output is not published: c2patool echoes the asset
        # path the caller submitted.
        raise C2PASigningError(f"c2patool exited with {result.returncode}")
    return result


def _verify_signed_asset(tool: str, asset: str) -> dict[str, Any]:
    result = _run_c2patool([tool, asset], "verify", verification=True)
    try:
        payload = json.loads(result.stdout) if result.stdout.strip() else {}
    except json.JSONDecodeError as exc:
        raise C2PAVerificationError(f"c2patool returned non-JSON verification output ({exception_kind(exc)})") from exc
    if not isinstance(payload, dict):
        raise C2PAVerificationError("c2patool verification output was not a JSON object")

    active_manifest = payload.get("active_manifest")
    manifests = payload.get("manifests")
    has_active_manifest = isinstance(active_manifest, str) and bool(active_manifest.strip())
    manifest_count = _manifest_count(manifests)
    if not has_active_manifest and manifest_count == 0:
        raise C2PAVerificationError("c2patool verification output did not include a manifest")
    if payload.get("validation_state") != "Valid":
        raise C2PAVerificationError("c2patool verification state was not Valid")

    validation_status = payload.get("validation_status", [])
    if not isinstance(validation_status, list):
        raise C2PAVerificationError("c2patool verification status was not a list")
    trusted = True
    warning_codes: list[str] = []
    if validation_status:
        if _is_untrusted_signing_credential_only(validation_status):
            trusted = False
            warning_codes.append(_UNTRUSTED_SIGNING_CREDENTIAL_WARNING)
        else:
            raise C2PAVerificationError("c2patool verification reported fatal validation status")
    return {
        "active_manifest": has_active_manifest,
        "manifest_count": manifest_count,
        "trusted": trusted,
        "warning_codes": warning_codes,
    }


def _is_untrusted_signing_credential_only(validation_status: Any) -> bool:
    if not isinstance(validation_status, list) or len(validation_status) != 1:
        return False
    status = validation_status[0]
    return isinstance(status, dict) and status.get("code") == _UNTRUSTED_SIGNING_CREDENTIAL_STATUS


def _manifest_count(manifests: Any) -> int:
    if isinstance(manifests, dict):
        return sum(
            1
            for label, manifest in manifests.items()
            if isinstance(label, str) and bool(label.strip()) and isinstance(manifest, dict)
        )
    return 0
