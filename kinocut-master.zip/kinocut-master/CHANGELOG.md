# Changelog

All notable user-facing changes should be recorded here.

This project follows a simple release-note style:

- `Added` for new capabilities.
- `Changed` for behavior changes.
- `Fixed` for bug fixes.
- `Security` for vulnerability fixes.

## Unreleased

### Added

- Turn plain spoken direction into a deterministic, reviewable edit plan with `video_direct`, then explicitly execute it with `video_direct_apply(confirm=true)` or `kino direct "WORDS" -i INPUT --apply` (#458). Plans disclose defaults, unknown phrases and at most one question; voice memos reuse optional local transcription. Apply validates the entire tool/path/argument chain before rendering and returns per-step receipts on success or failure.
- Support trims, silence removal, pacing, delivery formats, center reframing, -14 LUFS loudness, synchronized captions, muting and final-video thumbnails. Both tools live in the `intent` profile and the `video_plan_ops` family. Development now has 208 MCP tools / 178 CLI commands; published 2.0.1 counts are unchanged.

### Added
- **`dark-grade` quality profile.** Footage graded dark on purpose (night, noir, low-key interiors) no longer scores as underexposed: `video-quality-check` and `release-checkpoint` take `--profile dark-grade`. A black or flat frame still fails. (#760)

### Changed

- `video_trim`, `video_merge` and `video_shorts` now write a review card next to the output by default and
  return it as `review_card` plus a `preview_directive`, so an agent can show the cut without
  a second call. Pass `review=False` to skip it. A card that fails to render is reported in
  `review_card.error` and never fails the edit.

### Fixed

- CLI commands that draw a progress bar (`kino trim`, `kino video-ai-transcribe`, …) no longer hang on a
  real terminal. The home-directory redaction stream wrote through Rich's live-display proxy and recursed
  into itself; it now writes to the terminal underneath the proxy, so human output still shows `~` and JSON
  still carries absolute paths.

## 2.0.1 - 2026-11-10

### Fixed

- `video_review_card` works on a plain install. In 2.0.0 it needed Pillow to shrink the
  contact sheet, which only optional extras install, so it failed with
  `No module named 'PIL'`. It now shrinks the sheet with FFmpeg.

## 2.0.0 - 2026-11-10

Your agent now sees 18 tools instead of 20, and through them it reaches every one of
Kinocut's 205 operations. In 1.16.5 the default list reached only the 20 it named. The
whole tool listing is also smaller: about 21.7 KB by default (26.5 KB in 1.16.5) and about
178 KB with `KINOCUT_TOOLS=all` (225 KB). That is less context spent before the first
edit. Cuts also leave the terminal: a review card in Hermes chat with an Approve & export
button, and an opt-in Hermes Desktop plugin that shows which Kinocut tool is running.

This is a major release because the default tool list changed. If your agent called one
of the twelve tools that left it, read **Breaking changes**.

### Thanks

- Thanks to [@cnw-L](https://github.com/cnw-L) for quoting the lavfi `movie=` filter value so Windows drive paths survive filter graphs ([#532](https://github.com/KyaniteLabs/kinocut/pull/532)). It shipped in 1.15.3 without credit; this backfills it. Everyone who has contributed from outside the core team is credited in the [README](README.md#contributors).

### Breaking changes

- **The default MCP surface is 18 tools.** An 8-tool hot path (`video_info`, `video_trim`, `video_merge`, `video_add_text`, `video_add_audio`, `video_extract_frame`, `video_shorts`, `video_doctor`), eight operation families (`video_edit_ops`, `video_effects_ops`, `audio_ops`, `video_ai_ops`, `image_ops`, `video_qc_ops`, `video_plan_ops`, `platform_ops`) that reach all 205 operations, and `list_operations` / `describe_operation` to find one and fetch its schema. Twelve tools left the default list: `search_tools`, `hyperframes_doctor`, `video_add_texts`, `video_convert`, `video_resize`, `video_speed`, `video_validate_text_layout`, `video_quality_check`, `video_review_package`, `video_workflow_inspect`, `video_rescue_inspect` and `video_project_create`. Each still works. `list_operations` replaces `search_tools`, which is still listed under `KINOCUT_TOOLS=all`; for the other eleven, call the family with `{"operation": "<name>", "params": {...}}`, or list it by name with `KINOCUT_TOOLS=all` or a profile that carries it. Family dispatch runs the same code and returns the same result as the named tool. (#663, #717)
- **Read-only tools no longer take `overwrite`.** `video_info`, `video_info_detailed`, `video_doctor`, `search_tools`, `list_operations` and `describe_operation` never write, so they stopped asking for permission to. A client that still passes `overwrite` gets a validation error; drop the argument. (#737, #747)
- **Tool schemas lost their auto-generated titles.** The property titles pydantic derives from parameter names, the `<name>Arguments` / `<name>DictOutput` schema titles and annotation titles that repeated the tool title are gone. Property names, types, defaults and validation are unchanged. A client that keyed on those titles should key on property names. (#718)

### Added

- **Review a cut in Hermes chat.** `video_review_card` writes a self-contained HTML card (contact sheet, facts, and Approve & export / Dig in / Try another range buttons) that Hermes chat shows inline. Reach it through `video_edit_ops` or `KINOCUT_TOOLS=all`. (#723)
- **Watch renders from Hermes Desktop.** An opt-in Desktop plugin, shipped beside the Hermes plugin's `mcp.json`, shows which Kinocut tool is running in the status bar and adds a "Kinocut renders" pane you open from the command palette. (#724)
- **Review a cut on the TV.** The Hermes plugin skill can show a cut on a paired Hermes Gadget TV and map the remote's Approve and Reject to Approve & export and Try another range. The TV needs a URL it can fetch; Kinocut does not serve one yet, and this path has not been tested on a real TV. (#725)
- **Quality gates for screen recordings.** `video-quality-check` and `release-checkpoint` take a content profile (CLI `--profile`, MCP and Client `profile`): `default` for camera footage, `ui-capture-dark` and `ui-capture-light` for screen captures. Dark-mode demos no longer need a blanket `--min-score` drop, and a blank or black capture still fails. Reports record the profile and its thresholds. (#679)
- **Loudness you can see.** `normalize_audio` returns the measured loudness before (`measured_input`: I, LRA, TP) and after (`measured_output`: I, TP) on the CLI, the Client and MCP. (#699)
- **The 360 flow refuses what it cannot render.** A raw Insta360 `.insv` or a clip that is not a ~2:1 equirect is rejected at intake and again at render, before any decode, with a message that says what to export instead. (#664)
- `qa/run.sh` runs a source-cited catalog of operator journeys against an isolated install, and says which actions it did not cover. (#670)

### Changed

- **Tool text is half the size.** Each parameter's help now sits on the parameter instead of in an `Args:` block in the tool description, and long tool and family descriptions were cut to what an agent needs. Description text across `KINOCUT_TOOLS=all` fell from 62.5 KB to 31.2 KB. (#719, #738, #740, #741, #742)
- The MCP server starts about 25 ms sooner: it loads the receipt contracts only when `video_add_audio` writes a receipt. (#743)
- `video_fix_design_issues` says what it does: it fixes brightness and saturation and leaves audio alone. Use `video_normalize_audio` for loudness. (#684)
- `kino hyperframes-doctor` prints one line per check with a hint and exits 1 only when a required check fails. (#681)
- The docs were rewritten from the code: tool, command and client indexes are generated, and pre-2.0 audits and roadmaps moved to `docs/archive`. (#750, #752)

### Fixed

- MCP `resources/list` was empty in 1.16.5; the resources are listed again. (#658)
- On hardened hosts that refuse a read-open of `/` (some seccomp, LSM and container setups), every output write failed with `Atomic output could not preserve directory identity`. Writes work there now, with the same no-follow guarantee. (#658)
- A killed `kino` command no longer leaves FFmpeg encoding in the background: each command runs under the orphan watchdog. It costs about 33 ms per command on Linux and 89 ms on macOS. (#659)
- When brightness and saturation fixes both apply, `video_fix_design_issues` now outputs both. Before, only the last survived while `fixes_applied` listed both. (#688)
- `release-checkpoint` keeps `all_passed` false when any gating check fails; the score gate reports its own `gate_passed`, `min_score` and `failed_checks`. (#682)
- Retry hints name a `kino` command only when one exists. (#687)
- `sound-plan-validate` names the field that failed (`validation_error`, `invalid_plan`, `details: [{loc, msg, type}]`) instead of `unknown`. (#683)
- Text overlays work on Linux hosts without DejaVu Sans, such as Arch: the default font falls back to fontconfig's sans-serif, and per-user fonts in the XDG font directory are found. (#697, #707)
- AI upscaling and the loudness checks work on FFmpeg 9. (#706)
- Polling a render job while its runner writes the next record no longer fails with `render job not found`. (#709)
- Cancelling a mix render on Python 3.11 is no longer silently ignored. (#712)
- Normalized audio keeps its true-peak headroom: a redundant AAC re-encode after normalization is gone. (#667)
- `video_shorts` with `overwrite` no longer refuses its own `.srt` sidecar, and caption offsets stop at the end of the source. (#658)
- Hyperframes preview hands the live preview back to its caller instead of reporting that it exited. (#668)
- `kino review-decide` never narrows the overwrite consent it inherits. (#673)
- An error that repeats a rejected number caps it at 24 characters for plain `int` and `float` values too. (#745)

### Removed

- Three audio bridge modules nothing imported (`kinocut.audio_engine.integrations.librosa_bridge`, `meltysynth_bridge`, `soundfile_bridge`) and the unused `object_matte.temporal.expand_sampled_masks` helper. No tool, CLI command or Client method used them. (#744)
- The `audio-analysis` extra installs only `numpy`, and `audio-all` / `all-ai` no longer pull `librosa` or `msgpack`: nothing imports them now that the audio bridges are gone. `pip install kinocut[audio-analysis]` still works. The lockfile drops 10 packages. (#748)

### Upgrade

```bash
pip install --upgrade kinocut==2.0.0
claude mcp add kinocut -- uvx --from kinocut==2.0.0 kino --mcp
```

`mcp-video==1.6.21` installs `kinocut==2.0.0` for anyone still on the old name. To keep
the old named tools in your agent's list, set `KINOCUT_TOOLS=all` or a profile such as
`profile:editor`.

## 1.16.5 - 2026-10-27

### Added

- Add an opt-in exact probe: `kino info <file> --exact`, `Client.info(path, exact=True)` and MCP `video_info(input_path, exact=true)` additionally report `frame_count` (decoded with ffprobe `-count_frames`), `frame_count_source: "decoded"`, and the raw `r_frame_rate` / `avg_frame_rate` strings exactly as ffprobe reports them. Values that cannot be measured (for example a `0/1` rate) are `null`, never a default. The default `info` output and cost are unchanged; the exact mode decodes the whole video stream and uses a longer probe timeout.
- Add a curated 20-tool default MCP registration, `KINOCUT_TOOLS=all` and profile expansion, hidden-tool discovery, the one-call `video_shorts` flow, the read-only `video_doctor` preflight, eyes-free retry invocations, deferred core imports, and MCP progress bridge coverage. Telemetry, network, and overwrite defaults remain unchanged.

### Fixed

- Restore master CI after the #641/#642 QoL-pass merges: mechanical ruff-format on the 10 drifted files, GitHub-canonical topology test aligned with #645, hidden MCP tools stashed (not deleted) so `KINOCUT_TOOLS=all` can restore them, `video_shorts` decomposed under the 80-line function cap, and hosted FFmpeg apt install given a longer bound plus retries. Do not touch npm/ or the mcp-video shim packaging.
- Pin repo-level skill install recipes to `kinocut==1.16.4` and drop `claude mcp add` / unpinned `uvx --from kinocut` host-mutation instructions. Plugin skills were already pinned; the cloneable `skills/` tree now matches.
- The recipes now track the released runtime: every current install/launch surface pins `kinocut==1.16.5`.
- Ship the Apache-2.0 `LICENSE` file in the npm `kinocut` tarball (`files` now lists `bin/` and `LICENSE`). The published 1.16.4 tarball declared `license=Apache-2.0` without the license text, which Apache-2.0 §4(a) requires to accompany the distribution; the fix surfaces from the next npm release onward.
- Ship the Apache-2.0 license text in the `mcp-video` compatibility package on PyPI: `LICENSE` in the sdist and `<pkg>.dist-info/licenses/LICENSE` in the wheel, plus a License section in the shipped README. The publish gate (`check-built-artifacts.py`) now rejects any wheel or sdist that omits its license text. The published 1.6.19 artifacts declared Apache-2.0 without the text; the fix surfaces from the next mcp-video release onward.

### Acknowledgments

- Exact probe contribution: [@Beritwu](https://github.com/Beritwu), [#599](https://github.com/KyaniteLabs/kinocut/pull/599) (the squash already carries the co-author credit).

## 1.16.4 - 2026-10-23

### Security

- Disable optional vision provider calls by default, even with inherited credentials. Operators must explicitly select `KINOCUT_VISION_MODE=local` or `remote`; `off` disables both legacy adapters. Local product descriptions require a loopback endpoint and disable environment proxies, redirects and cloud fallback.
- Keep the separate fixed Anthropic QC worker unavailable for local/custom product routes. Neither `use_ai` nor `require_vlm` grants network permission.
- Disable Revideo telemetry for installation and rendering unless the operator explicitly sets `KINOCUT_REVIDEO_TELEMETRY=true`.
- Suppress Hyperframes telemetry, passive update checks and automatic skill installation in both command and preview processes. Remove inherited provider credentials and skip upstream captions/analysis during capture, snapshots and stills; use host image inspection instead.
- Require explicit Hyperframes telemetry consent for Docker rendering and browser previews outside verified versions 0.8.104/0.8.140; rejected previews leave existing previews running.

### Changed

- Document provider-neutral review through the host's configured image tools and the limits of the legacy provider adapters. Correct the disclosure: product descriptions and optional semantic QC can send frames; FFmpeg color grading is local.
- Existing users of legacy provider calls must explicitly opt in after upgrading. Tool names and signatures remain compatible.

## 1.16.3 - 2026-10-23

### Security

- Refuse existing outputs unless the caller explicitly supplies MCP/Python `overwrite=true` or CLI `--overwrite`. Existing non-media files require inode evidence that Kinocut created them for the same job; agent configuration homes remain protected.
- Publish new files without replacing a destination created during rendering, and apply artifact guards to saved plans, receipts, font/model caches and HLS playlists.

### Changed

- Retain durable receipt/shorts-plan ownership witnesses across worker restarts. Older artifacts without witnesses stay protected; create a new job instead of adopting or replacing them.
- Remove secondary installers from plugin skills, disclose optional network access, and document a small Hermes tool allowlist to reduce per-request schemas.

### Fixed

- Check completed project destinations, including symlink redirects into protected agent homes.
- Preserve MCP request-context annotations and progress reporting on Python 3.14 without exposing context in tool input schemas.

## 1.16.2 - 2026-10-21

### Added

- Accept rational frame rates such as `30000/1001` for `create-from-images` in Python, CLI (`--fps`) and MCP, and add `--list FILE` / `list_file` input with one image path per line so long frame sequences no longer pass through argv.

### Changed

- `create-from-images` now rejects frame rates above 60 (`MAX_EXPORT_FRAMES_FPS`) with `validation_error` for Python and CLI callers too; previously only the MCP tool enforced the bound.
- `create-from-images` accepts at most 18,000 images (`MAX_IMAGE_SEQUENCE_FRAMES`, 10 minutes at 30 fps) from positional paths, MCP `images` or a list file, and reads at most `MAX_IMAGE_SEQUENCE_LIST_BYTES` (18,432,000) bytes of a list file. Over-limit input fails with `validation_error` (`too_many_images` / `list_file_too_large`) before any image is checked.
- The MCP `video_create_from_images` tool checks the image count, validates `list_file` with `_validate_input_path`, and enforces the frame-rate range before calling the engine. Rational rates take at most 18 ASCII digits per term.

### Fixed

- Make `create-from-images` frame-exact: N inputs now encode exactly N frames at the requested rate, with no duplicated trailing entry and no float-duration surplus. Even-dimension PNG inputs skip the per-image normalization pass: each is hard-linked into a private directory and its dimensions are read through that link, so a path renamed over or replaced by a symlink after validation cannot reach FFmpeg unchecked. Inputs that are symlinks at link time, are not even-dimension PNGs, or cannot be hard-linked fall back to the normalizer; inputs are never copied.
- `create-from-images` works when the temporary directory path contains `%`.
- MCP Registry: republish `tech.kyanitelabs/kinocut` as the local `uvx kinocut` stdio package. The 1.16.1 registry entry listed only a hosted URL and no installable package. A test now fails if `server.json` advertises a hosted remote or drops the package, and the release workflow signs in with the `kyanitelabs.tech` domain key for this namespace.
- Compatibility shim `mcp-video` 1.6.17 installs `kinocut` 1.16.2.
- Stop `test_inherited_writer_process_group_is_terminated` from failing intermittently when the process exits between its status checks.

### Acknowledgments

- Thanks to [@Beritwu](https://github.com/Beritwu) for contributing the frame-exact `create-from-images` rewrite, rational frame-rate and `--list` / `list_file` support, input bounds, and regression tests in [#616](https://github.com/KyaniteLabs/kinocut/pull/616), and for working through two review rounds (starting in [#615](https://github.com/KyaniteLabs/kinocut/pull/615)).

## 1.16.1 - 2026-10-05

### Fixed

- Copy source audio directly from its original container in GPU shader and Real-ESRGAN media reconstruction, preserving AAC/MP3 packets, timestamps and codec priming; propagate mux failures and reject missing shader dependencies before extracting media.
- Bound shader frame extraction to its existing 7,200-frame limit plus one overflow sentinel, and retain final encoded audio packets during AI upscaling instead of truncating them with `-shortest`.
- Return typed processing errors when shader dependency probes or render subprocesses fail to start or time out, retaining bounded renderer diagnostics.
- Propagate upscale frame-rate and audio-probe failures instead of treating failed inspection as a default frame rate or absent audio.
- Verify detached render group quiescence on macOS from bounded process-state observations, so retained zombies do not prevent cancellation and resume after descendants stop.
- Use a live process supervisor on macOS, where signaling a group containing only a retained zombie fails despite available nonreaping wait APIs. Cleanup retains process ownership and original exit status.
- Preserve MOV/MP4 faststart and encoded packets for descriptor-anchored macOS outputs by relocating the index through bounded positional I/O instead of reopening shared-offset `/dev/fd` aliases.
- Sign C2PA exports through unique owned staging files and publish only after verification; preserve foreign temporary files and the original export when signing fails.
- Verify object-matte and FSRCNN model downloads in owned staging before publishing the cache, preserving unrelated temporary files and prior cached bytes on download failure.
- Discover FFmpeg 8.1 filters from its two-character capability flags while retaining older three-character flags and exact selected-binary identity checks.

### Changed

- Refresh current website and directory status after verifying the 1.16.0 site and approved social images; retain final owner acceptance, vendor identity resolution and distribution project gates separately.

### Acknowledgments

- Reported-by: [@Mimatovitch](https://github.com/Mimatovitch), [#594](https://github.com/KyaniteLabs/kinocut/issues/594).
Thanks to [@Mimatovitch](https://github.com/Mimatovitch) for reporting [#594](https://github.com/KyaniteLabs/kinocut/issues/594), and [@Zoroassistant23](https://github.com/Zoroassistant23) for investigating it and proposing a patch and test in [#595](https://github.com/KyaniteLabs/kinocut/pull/595). That PR was not merged; a separate cleanup change shipped in [#596](https://github.com/KyaniteLabs/kinocut/pull/596). See the [1.16.1 release notes](https://github.com/KyaniteLabs/kinocut/releases/tag/v1.16.1) for fuller context.

## 1.16.0 - 2026-10-02

- Accept the approved optional icon in MCPB readiness aggregation while requiring every runtime/optional receipt to match the exact allowlisted build inventory.

- Apply the approved colored logo and Chakra Petch Bold700 identity to the README hero, GitHub preview source and licensed vector wordmark; canonical website and GitHub settings cutovers require live verification.
- Include the approved 512px KinoCut icon in the bounded MCPB archive and source distribution; the approved lettering is integrated, while public branding cutover and Desktop import acceptance remain separate gates.

- Align existing operator routes: MCP/CLI audio mixing, CLI ducking/HLS, explicit human motion receipts, 360 intent/review controls, and Python operation estimates. Published surface: 203 MCP tools / 177 CLI commands.
- Persist and enforce MCP repurpose quality/checkpoint policy before durable job success; changed inputs, outputs or frozen policy invalidate evidence.
- Share trim/frame sampling, conversion bitrate/two-pass and normalization controls across Python, CLI and MCP. Explicit zero timestamps remain supported.
- Keep MCP audio mixing responsive by running the synchronous engine in a worker thread; add a bounded concurrency regression.
- Reject invalid, nonfinite and overflowing local operation estimates and bound operation names. Estimates remain dimensionless heuristics, not billing or measured latency.
- Require explicit JSON booleans for MCP audio preservation and repurpose checkpoint/start policies before SDK coercion.
- Reject oversized or duplicate-key audio descriptions before MCP SDK JSON preprocessing; share bounded validation with Python and CLI.
- Resolve native CI bundle/wheel paths from candidate metadata rather than stale release filenames.
- Admit CLI planning/review JSON files through bounded nonblocking regular-file reads before parsing: 1 MiB for intent/sound plans, retaining the post-rescue 4 MiB ceiling. JSON nesting is capped at 128. Oversized, malformed, deeply nested and nonregular artifacts return redacted typed errors before engine dispatch.


### Added

- Python `Client.record_motion_acceptance` records a separate source/report-bound whole-film human-viewing attestation, complete coverage and purposeful-motion/intended-cut dispositions. Invalid or unresolved evidence cannot grant acceptance (#583).
- Explicit `KINOCUT_VISION_MODEL` plus `ANTHROPIC_API_KEY` enables one bounded Anthropic keyframe request through an isolated standard-library worker. No default model, retry or request occurs from SDK installation alone; results cover sampled frames, with live provider accuracy separately unverified.
- Whole-package module/function size guardrails cover both runtime packages, including newly added subsystems.
- Optional MCPB icon packaging accepts only a referenced `icon.png` with bounded regular-file, PNG-structure and archive-inventory validation, using the shared resource limits. No placeholder artwork is bundled; approved artwork and actual Desktop-host acceptance remain separate.

- Missing FFmpeg encoders and filters return bounded structured dependency advisories through existing processing errors. Suggested alternatives require an intentional caller decision; no codec substitution or dependency installation occurs.
- Native Gemini CLI MCP setup examples and an on-demand extended agent guide, with host data-egress boundaries and installed-schema discovery.
- Temporal inspection returns and persists source-hash-bound `motion_coherence` with chronological low-resolution luma-difference windows, coverage/gaps/budget and advisory transition candidates. Frame-budget overflow rejects instead of silently truncating; human viewing and acceptance remain separate (#583).
- Python `Client.mix_audio` layers timed sounds in one AAC encode with picture stream copy, source-audio preservation by default, bounded streaming fades and staged validation; `Client.duck_audio` exposes the existing plain-file sidechain mixer. Neither adds MCP/CLI names or a governed audio-bed receipt (adapted from draft PR #573; issues #572 and #549).
- `Client.ai_color_grade` accepts optional `lut_path` for explicit `.cube` LUTs (#556).
- Deterministic task-phrase aliases for tool discovery, including filler cleanup, resumable renders and subject framing. Exact tool-name matches retain priority; discovery neither invokes models nor establishes optional-backend availability.
- Reproducible runtime-source allocation inventories, output-equivalence microbenchmarks, architecture review, and current ASR/typed-decision research under `docs/research/runtime-allocation/`. Source share is not execution cost; no new ASR, VLM or Jev backend is installed or integrated by this work.

### Security

- Raise security minimums and refresh the lock for MCP, AnyIO, Click, cryptography, PyJWT, pydantic-settings, python-multipart, Starlette and optional Pillow. Optional extras also raise msgpack, setuptools, urllib3 and Torch security floors; TorchVision and required CUDA/Triton packages are resolved compatibly without adding these backends to the base install. A complete 159-distribution lock audit retains only BasicSR’s unpatched SLURM advisory, whose distributed initializer is not called by KinoCut. The legacy BasicSR/TorchVision import incompatibility and actual optional inference remain unverified; an OpenCV fallback does not establish equivalent quality. The prior development environment matched 45 distinct advisory IDs across these packages; these matches do not establish exploitability. Pillow user-image decoding is a plausible exposure. No exploit fixtures were executed. Dependency and artifact audits remain separate from native binaries, model weights and fleet verification.

### Changed

- Detached render jobs call the workflow engine directly, preserving typed failures, cancellation, resume and lineage while removing MCP transport imports. Three-trial same-host import medians changed from 0.847s before repair to 0.452s initially and 0.401s in the pre-review guardian checkpoint; rendering throughput is unmeasured.
- PR safety tests use bounded two-worker file grouping with unchanged selection, assertions and JUnit reporting. The same 257-case baseline measured 204.2s serial versus 112.4s with two workers; full-suite speed is not inferred.
- ASR reuses same-job verified PCM instead of decoding identical WAV bytes twice. Sound policy constants are centralized with compatible aliases and static package exports, resolving thirteen maintenance TODOs.
- Voice-batch receipts expose `loudness=null` and `loudness_assessment_status="not_evaluated"` instead of fabricated -16 LUFS/-1 dBTP compliance. Measured receipt paths retain their evidence; consumers needing loudness must meter the assembled master.
- Support claims select staged local-access MCPB, retain paid generation as an unavailable draft and separate deterministic sound processing from full-episode/listening acceptance. The 1.15.3 release draft and tag remain bound to their original source and notes; these changes shipped in 1.16.0.

- Split Client mask operations and CLI quality renderables into focused modules while preserving public methods, aliases and formatter behavior. Design checks share source-aware, bounded, defensive-copy measurements rather than maintaining divergent analysis paths.
- Signalstats reads compact bounded frame output and computes running means instead of retaining full FFprobe frame dictionaries. ASR frontend resampling uses the installed FFmpeg band-limited converter with disclosed version/policy, bounded PCM input and exact-length checks; native 16 kHz audio bypasses conversion. Source-bound resource and synthetic anti-aliasing trials do not establish model latency, recognition accuracy or speech quality.
- `noise_reduction` defaults to a -50 dB noise floor instead of -25 dB; explicit `noise_level` remains supported (adapted from draft PR #575; issue #574). This conservative default does not establish speech recognition or universal denoising quality.
- Shape masks default to alpha-capable MOV output; explicit MP4 output composites the mask over black instead of pretending to retain alpha (#551).
- Visual review distinguishes frame sampling from semantic assessment. Without an executable scorer, `video_qc_vision` returns `not_evaluated` or `inconclusive`; `require_vlm=true` blocks instead of passing. Installing a provider SDK does not establish inference availability.
- Default D42 voice-style and speaker-identity ports report `d42_voice_seam_unavailable` until a perceptual backend is supplied. Cryptographic audio hashes remain integrity evidence and no longer produce invented voice-similarity scores.
- Detached render cancellation and termination retain stop intent and runner identity until the process group is observably stopped and its job lease is released. Unconfirmed stops remain pending; queued cancellation is immediate. Reconciliation no longer treats an absent liveness callback as evidence that work stopped.
- Host workflow instructions separate source-backed creative proposals from execution and protect names, numbers, qualifications and negations. A prepared plan or model package is not presented as completed inference.

### Fixed

- Match the documented motion-review CLI receipt envelope and accept bounded report files beyond operating-system argument limits. Durable repurpose receipts remain pending during release evaluation and record typed failure evidence on quality/binding rejection, preserving rendered-step hashes and resume progress. Receipt inspection exposes the post-render failure; failed receipt writes withhold the advertised artifact where withdrawal is possible.
- Admit valid longform producer motion reports with a dedicated byte budget, and accept bounded dispositions/watched-interval files so the complete review journey avoids OS argument limits. Preserve inline inputs, source/report hashes and unverified human-attestation semantics. Reject non-object review artifacts with a typed, redacted validation error before routing ordinary or 360 review decisions.
- Return typed validation errors from staged artifact selection, and report publisher verification timeouts as a clear processing error with a nonzero exit and temporary-file cleanup.
- Verify prospective publication claims on the existing publisher runner after registry writes. The live checker uses a temporary claims file and preserves failures without prematurely changing tracked public status or adding another hosted job.
- Include the canonical sound package in Docker builds and execute `sound-capabilities` in the built image. A safe representative build reproduced a wheel with no sound modules and a missing-module CLI failure; the repaired context contains all 156 sound entries and returns capability metadata in a fresh environment.
- Repair canonical console-script ownership after pip replaces older compatibility shims. Safe fixtures reproduced a missing `mcp-video` executable despite `pip check` success; publishing validates upgrades from both 1.6.0 and 1.6.14, reinstalls the canonical wheel without changing resolved dependencies, and verifies all three aliases before and after new-shim removal. Migration instructions include the same explicit repair.
- AI upscaling caps actual frame extraction with an overflow sentinel before model initialization; underestimated metadata cannot bypass the frame budget. Both existing backends stage final media atomically and reject source aliases, preserving prior output on reconstruction failure. Failed OpenCV frame writes and failed source-audio extraction abort instead of publishing shortened or silent media. Native extraction and controlled publication fixtures cover these repairs; model inference and perceptual quality remain separately unverified.
- The metadata-only `mcp-video` compatibility installer delegates console-script ownership to its canonical Kinocut dependency. Removing the shim no longer deletes the canonical `mcp-video` executable; release upgrade checks exercise all three CLI aliases after shim removal.
- Release preparation synchronizes the 1.16.0 Python/npm/registry/staged-launcher candidate with the 1.6.15 compatibility shim. The editable-root lock identity and missing optional matte dependencies are repaired; nine advisory-affected packages are updated, with one required typing-extensions update. Public dependency floors exclude the audited affected versions, including Pillow in optional extras. Published claims stay on 1.15.3 until publication is verified. Fleet instructions require per-consumer package, interpreter, restart and smoke-test evidence rather than inferring rollout from a merge.
- The GitHub Hyperframes integration job explicitly opts into its real-CLI tests and rejects missing, empty or skipped-only JUnit results. Checker-only and CI-workflow changes trigger hosted PR guard tests as well as master code checks; large changed-file lists cannot become false negatives through an early-closing grep pipe. The result guard imports its byte ceiling from shared resource limits and its execution minimum from shared validation policy. Its CLI is pinned to the observed 0.8.104 version, package lifecycle scripts are disabled, and job/install/test deadlines are explicit. The live project fixture rejects lint warnings as well as issues; these checks cover CLI discovery and HTML-project validation, not browser rendering or paid providers.
- Master and hosted PR change detection preserve literal Git pathnames through NUL-separated records. Unicode, tabs, newlines, backslashes and quotes cannot hide runtime changes; rename detection is disabled so removed runtime paths still trigger validation when moved into docs. Failed Git comparisons cannot publish a successful skip. Owned temporary path lists are removed on success and failure, logging escapes filenames, and classification has a one-minute deadline. Real isolated Git fixtures cover root mappings, unusual names, deletion, both rename directions, large lists and failed-reference cleanup.
- Seven Linux FFmpeg setup phases check for both `ffmpeg` and `ffprobe`, use `--no-install-recommends`, and have a 45-minute phase ceiling. Existing Hyperframes' 30-minute job ceiling remains the tighter bound for that lane. Version/filter assertions and explicit FFmpeg-version matrix installs are preserved. The main CI runtime and skip message identify Python 3.14; its legacy status-context name remains stable. These changes reduce installation footprint and bound provisioning stalls without claiming a measured speedup.
- Portable POSIX supervisors release their own stdout/stderr after native completion while retaining group ownership, fixing macOS quality-reader EOF timeouts. Forced-supervisor reader tests preserve genuine descendant-writer deadlines and distinguish native from supervisor identities.
- POSIX command completion retains the unreaped leader until owned-group shutdown; platforms without nonreaping wait support keep a live supervisor and report native status through a bounded private pipe. Cleanup refuses externally reaped identities, preserves original overflow/callback errors, and bounds signal-reader joins. Spawn failures now return redacted typed processing errors instead of raw OS exceptions. Windows startup failure still stops an unassigned suspended child through its stable handle.
- Render cancellation rechecks group quiescence and the lease when shutdown completes during initial verification, avoiding a false pending identity error. Native CI provisions a drawtext-enabled macOS FFmpeg; Windows fixtures check raw font paths and exact platform diagnostics while retaining real render/decode assertions.
- Detached-worker media commands retain their job lease under a parent-liveness guardian, so hard worker termination stops native FFmpeg and ordinary descendants instead of leaving processing alive. Normal commands are reaped. Controllers never signal reusable recorded PIDs: current workers consume stop intent themselves; unresponsive legacy workers remain pending until shutdown is proven. Abnormal zombies still require host PID1 reaping.
- Shared FFmpeg command runners enforce captured stdout/stderr and binary-output ceilings while draining; overflow rejects instead of returning truncated success. Sink writes reject invalid byte counts. POSIX sessions and Windows kill-on-close Jobs clean up owned descendants, including children whose leader exits successfully.
- Timeline and black-measurement metadata use owned stdout sinks with byte checks before disk writes; existing packet, line and deadline bounds remain.
- Anchored publication creates missing ancestry safely, verifies directory/inode identity after replacement and reports detected partial output explicitly. Composite receipt failure after media commits returns the committed media identity without unsafe rollback; exclusive destination-writer ownership remains required.
- Google Fonts downloads run in an isolated deadline-limited worker with allowlisted keys, byte ceilings and bounded diagnostics. Owned cache staging plus structural SFNT/TTC checks reject incomplete tables and prevent interrupted downloads becoming cached success. Windows unresolved font families fail before FFmpeg; macOS resolves Supplemental system fonts.
- AI scene thumbnails have a hard frame ceiling with an overflow sentinel and bounded width/height. Inconsistent duration metadata cannot silently truncate analysis or create unbounded tall thumbnails; invalid and overflowing durations return typed errors before extraction.
- Vision sampling rejects malformed, duplicate, nonfinite or excessive timestamps before extraction. Fixed-origin provider transport bounds successful bodies before parsing, refuses redirects/compression and closes error bodies unread; private request files are removed on every outcome.
- Perceptual voice evidence rejects invalid, nonfinite and out-of-range scores and malformed metadata instead of falsely reporting no drift; backend-detected drift remains authoritative.

- Audio processing rejects severity-tagged FFmpeg decoder errors even when the process exits zero, including ANSI-colored diagnostics on FFmpeg 6. Existing analysis/render/postflight passes are reused; strict flags alone do not establish rejection. Failure diagnostics preserve the actual process exit status and retain at most 4,096 UTF-8 bytes of complete-codepoint context; public messages retain the existing 500-character bound, while existing captured stderr is collected before extraction.
- Native Windows timeout tests verify actual child reaping, closed pipes and reader cleanup without an unsafe dead-PID signal probe. This is a test portability correction; production cancellation behavior is unchanged.
- ASR malformed-format/nonmono header failures retain `qa_input_invalid` before PCM allocation; explicit resource-budget violations retain `asr_over_limit`. Resampler defaults and input limits are exported from the sound package. Source-quality cache regressions verify retries, warm reuse and changed-source remeasurement.
- Design color analysis reports unavailable evidence instead of substituting neutral RGB values; available RGB estimates disclose their approximation. Auto-fixes use shared validated, staged publication, without implying a creative or perceptual acceptance pass.
- Workflow version/capability evidence uses the selected configured executable, caches only unchanged successful probes and retries failures. D41 audio-bed readiness respects configured FFmpeg/ffprobe and required filter availability; executable stat identity is not a content digest or backend execution guarantee.
- Normalization, attachment and ducking consistently select primary audio, use its actual extent/origin and reject invalid finite-number/backend ranges before encoding. Attachment and ducking validate staged AAC with full error-sensitive audio decode, preserving prior output on processing/result failure; genuine silence remains valid input.
- Multi-track picture duration uses bounded presentation packets even when stream duration exists. Added tracks use actual first-audio extent; attachment fades preserve native offsets and placement delay, materialize leading gaps and fade looped tracks at the final window. These additional measurement/decode passes strengthen timing rather than promising lower latency.
- Rescue accepts decimal timing boundaries within operand-ULP roundoff while retaining its existing 0.10-second/two-frame tolerance and rejecting materially out-of-bounds timing. Resume fixtures cancel after the requested repair and verify completed hashes without weakening the renderer; the shared endpoint helper remains compatible with body-swap callers.
- Design analysis respects configured FFmpeg/ffprobe executables through probing and measurement, including empty-PATH environments; audio and no-audio fixtures retain their intended evidence behavior.
- Longform replay bounds and advances chunks, validates finite source-bound transcript timing and preserves distinct repeated-word events with one-to-one overlap matching. Legitimate observed overlap prefixes disclose their trims; contradictory covered content fails instead of inventing trailing timestamps.
- Optional matte inference rejects malformed/nonfinite/batch/channel outputs and source/output aliases before model loading. Reframe verifies its plan-bound source identity before rendering and before staged publication, preserving existing delivery on stale or changing input.
- 360 director endpoint validation requires explicit cloud opt-in for non-loopback/LAN endpoints. Callbacks receive isolated fallback data, cannot rebind the plan source and cannot corrupt fallback through failed mutations; finite source-bounded plans and receipt source checks reject observed changes. These checks do not establish model availability, semantic coherence or immutable source snapshots through all consumers.
- Existing crop, rotate, watermark, fade, reverse, preview, overlay, split-screen, mask, normalize, filter, text, subtitle, stabilize and merge writers stage their output before publication; the single-clip merge copy also uses the owned destination descriptor. Partial writes and pre-publication failures preserve prior output. This scope does not make every engine operation or multi-file artifact a transaction.
- Shared FFmpeg publication binds staged writes to their owned descriptor, separates read provenance from output validation and rechecks publication identity while preserving explicit FFmpeg muxer/codec selector precedence. Composite media and plan files publish independently. Hostile in-place byte replacement and exclusive-writer requirements remain explicit limits; platform verification covers the named native CI controls.
- Progress readers bound unterminated diagnostics and retain subprocess cancellation/kill/reap ownership. Explicit caller deadlines are forwarded into the extracted runner after the aggregate timeout regression; the repaired sequential full-suite gate passed (8,005 tests; 189 skipped). The publication helper accepts its own staged postflight read without mistaking it for the original input.
- Video fades use bounded primary-picture extent and timeline origin, preventing longer audio tails or delayed picture starts from moving fades outside visible frames. Explicit odd crop dimensions reject before rendering; percentage crops derive even encoded dimensions and preserve exact offsets.
- Watermark top-center/bottom-center positions use actual margins; shared pixel, crop-bound, split-screen-layout, preview and media-rate validation reject malformed/nonfinite inputs before rendering. Resize tests use an actual rotated-display fixture rather than relying on an ineffective metadata-only remux.
- MCP rejects undeclared top-level parameters through the actual SDK argument model and advertises the same restriction in all 201 input schemas. Missing, mistyped, nested-invalid and mixed-invalid arguments return bounded structured validation errors without echoing submitted values; handler exceptions remain outside argument-error translation. Numeric-only parameters reject booleans before SDK coercion while explicit boolean fields and existing numeric-string compatibility remain supported. Public signatures and tool names remain unchanged.
- Serialized MCP argument nesting and integer-digit parser limits return the same bounded parameter error instead of leaking raw parser exceptions; handler errors remain separate.
- Audio timeline regression fixtures explicitly preserve delayed picture timestamps across FFmpeg 6/7 and verify source origin/duration before checking mixed audio; signal thresholds and picture-frame checks remain unchanged.
- Multi-track mixing preserves retained source-audio timing relative to the primary picture start and uses picture duration instead of a longer container audio tail. It stream-copies picture and encodes AAC once, then performs a separate bounded audio-only staged decode. Packet-timeline fallback caps producer packets with an overflow sentinel, drains FFprobe through a pre-write byte-limited owned sink, and retains its post-write metadata checks.
- Staged normalization accepts its advertised `.ogg`, `.opus`, `.aif` and `.aiff` output suffixes through the shared output guard.
- Runtime-source auditing reports stale classification manifests with a structured `stale_audit_manifest` error; audit entry-point/function-size regressions cover its maintained architecture limits.
- Hosted pytest failures publish bounded, escaped test-case annotations through the check API, retaining the original suite selection and exit status when raw log downloads are unavailable.
- Hosted safety reuses installed FFmpeg/ffprobe and bounds missing-dependency setup to ten minutes, avoiding redundant package-index refreshes on prepared runners.
- Trim and playback-speed edits render into a sibling staged output and construct their result before replacing the destination; render/result failure preserves existing output. Trim time validation rejects nonfinite values and overflow before FFmpeg runs. This does not make all engine writers transactional.
- Audio normalization selects PCM16 for WAV and AAC for supported M4A/video outputs, reports the observed codec/container, and publishes only after staged codec verification and full error-free audio decoding (#584).
- Hash-bound host loudness requests admit supported local encoded audio/video containers, meter the first audio stream without video decoding, and bind original source bytes to the unchanged EBU R128/true-peak delivery policy; bytes and standalone PCM contracts remain unchanged (#580).
- Project preflight accepts audio-only assets, measures loudness/decode evidence and marks color checks inapplicable rather than fabricating video evidence (#582).
- Accurate trimming seeks the input before decoding while retaining tested frame selections; absolute end is converted to the corresponding duration (adapted from draft PR #577; issue #576).
- Glow blends luma while preserving chroma; vignette darkens edges without the previous color cast (#560, #557).
- Ken Burns defaults to one output frame per input frame at the source frame rate, with continuous zoom, instead of multiplying ordinary video duration (#554).
- Macroblocking restores exact source dimensions for portrait and nonmultiple sizes; static shape masks loop for the bounded video duration and preserve feathering (#552, #551).
- Creation prompts preserve storyboard camera/lens directions and explicitly report generic, noncompiled prompt dialect. Style parsing accepts a bounded heading annotation, rejects malformed/duplicate declared headings and ends blocks at unrelated headings (#581).
- Hyperframes relative render paths resolve from the caller cwd consistently for rendering and output inspection. Still rendering honors `-o` and copies the requested artifact independently of mutable snapshots; missing stills and false render results fail. Still output remains PNG bytes, without extension-based transcoding; omitted output retains the existing snapshot path (#585).
- Cropping uses upright display dimensions and centered offsets for rotation-tagged phone video (adapted from draft PR #579; issue #578).
- Timed video layers and video masks start playback at their declared layer start instead of hiding already-advanced footage. Full-canvas and positioned non-normal blends support opacity and timing windows, with explicit RGB arithmetic; unsupported scale/rotation/mask geometry remains fail-closed (adapted from draft PR #567; issues #566 and #556).
- `add_audio(mix=True, duration_policy="loop_audio")` loops the added track with capped input/output duration. `pad_audio` with mixing remains explicitly unsupported (#555).
- Audio waveform extraction now reads real per-window RMS measurements instead of falling into synthetic output because of invalid FFmpeg metadata options. The overall mean uses duration-weighted linear power; silence stays finite, audio offsets remain aligned, final-window padding is compensated, and opposite-phase stereo is not mistaken for silence. Video decoding is disabled, aggregation frames and metadata output are bounded, and retained compatibility fallback is explicitly marked `synthetic=true`. Audio-only inputs now use the audio-capable probe instead of requiring a video stream (#582).
- Black-frame coverage uses decoded presentation intervals, including the terminal frame and short black spans. Variable frame rates and audio tracks longer than the picture no longer distort the ratio; corrupt or unverifiable decoding reports unavailable evidence.
- Visual quality thresholds receive normalized native 8/10/12/16-bit SDR luma/chroma in full or limited range. Motion measurement negotiates its pixel format before grayscale conversion. These repairs do not establish HDR delivery acceptance.
- Grayscale quality analysis explicitly applies the existing full-range gray convention at every depth, including TV-tagged gray inputs, fixing inconsistent measurements on FFmpeg 6.1 versus 7.1. Native YUV measurements are preserved. Source metadata is cached and shared with audio-stream checks; unusable metadata retries, and ambiguous mixed gray/color video streams report unavailable evidence.
- Quality measurement caching retains only successful, nonempty observations of unchanged source identity and analysis window. Failed observations retry, replaced files invalidate entries, and retained entries are bounded. Filesystem cache identity does not substitute for cryptographic provenance.
- Conversion validates a staged output before publication. Encoding, progress-callback, timeout or postflight failure preserves an existing destination; source and hardlink aliases remain rejected. Other engine writers are not covered by this conversion-specific guarantee.
- Content-addressed re-import verifies stored bytes and records lifecycle repairs without changing immutable manifests or erasing GC history. Backup ownership and interrupted-repair cleanup are checked; availability no longer relies only on file presence.
- A runner completing or failing during a stop request cannot discard its retained identity or overwrite the requested stop outcome before shutdown is verified.
- NIMA thumbnail candidates remain on disk through scoring and are cleaned up on success or failure, instead of being removed before the scorer could read them.
- Longform transcription reuses a Whisper model within one job while preserving decoding options and releasing job-owned references afterward. Voice-roster comparisons reuse extracted features, PCM parsing and palette-label counting avoid per-element Python loops, and pitch analysis bounds temporary windows. No model-quality or end-to-end latency improvement is claimed from these changes.
- Model verification, rescue inspection/verification, sound bindings and project hashing stream SHA-256 input instead of reading entire artifacts into Python memory; checksum verification remains enabled.
- Audio-only loudness, silence and related analysis passes disable video processing while preserving intended streams in delivery renders.
- Every FFmpeg/ffprobe child process now names `stdin=DEVNULL` explicitly (source contract pinned): children can no longer inherit — and consume or block — the MCP stdio protocol channel on any code path (integrator report #547; PR #559 fixed the central runners, this completes the tree).
- Merge transitions and the video-filter path (e.g. `sepia`) now pin `yuv420p` instead of inheriting `yuv444p`, so outputs play in browsers/phones and concatenate with yuv420p segments (#548, #556).
- `layout_pip` no longer passes a full ffprobe command to the raw-args runner — the call failed with `ValueError` on every invocation since the runner split (#550).
- `drawtext` font family names resolve to a concrete font file before reaching FFmpeg; the bare `font=<family>` option access-violated FFmpeg builds without fontconfig on Windows (0xC0000005) (#553).
- The PIL text-measurement font loader no longer fails silently with a `NameError`, which had pushed every measurement onto the fallback path (found while fixing #553).

### Docs

- The repaired local sequential gate passed 8,013 tests (189 skipped, 8 warnings); pinned Ruff and canonical imports also passed. Corrected hosted results remain pending at the pre-push checkpoint and belong to PR #587 exact-head checks.
- Record the merged PR #586 exact-head checks separately from the later whole-repository UltraQA ownership inventory, adversarial findings and focused gates. Supersede the independent four-case native-FFmpeg-six attribution with actual executable/source bindings; the separate native suites and real hosted FFmpeg-six checks remain valid historical evidence.
- Cross-platform core-runtime CI adds publication, compositor and signal-reader regressions after generating the separate clean-runtime receipt. At this pre-publication checkpoint, native Windows/macOS execution remains pending until the eventual PR exact-head hosted checks run; local substitutes and platform skips are identified explicitly.
- Refresh active release discovery to verified PyPI/npm 1.15.3 and compatibility shim 1.6.14; retain explicit GitHub release and MCP Registry drift. Review Google/Gemini audit claims against live site and pinned official sources, and qualify cost, privacy, performance and receipt claims.
- Document measured, unavailable and unevaluated quality evidence; waveform units and fallback; conversion publication; and projectstore repair, cancellation and resume contracts. Correct the waveform result example to its actual model fields.
- Keep published-release identity separate from development changes. Research benchmarks remain local measurements with their corpus, optional-provider and validation limits recorded.

### Acknowledgements

- Thanks to [@guillaume-hestia-projekt](https://github.com/guillaume-hestia-projekt) for draft PRs [#577](https://github.com/KyaniteLabs/kinocut/pull/577), [#575](https://github.com/KyaniteLabs/kinocut/pull/575), [#573](https://github.com/KyaniteLabs/kinocut/pull/573), [#579](https://github.com/KyaniteLabs/kinocut/pull/579) and [#567](https://github.com/KyaniteLabs/kinocut/pull/567), whose reviewed fixes were adapted locally. These acknowledgements do not claim those draft PRs were merged.
- Thanks to [@guillaume-hestia-projekt](https://github.com/guillaume-hestia-projekt) for the 15-issue production-integrator batch of 2026-09-24 (reports #546–#560 with repro + root cause) and PRs #558/#559, which landed within 24 hours.

## 1.15.3 - 2026-09-25

### Publication record

- PyPI and npm publication of 1.15.3 verified on 2026-09-30; published compatibility shim `mcp-video==1.6.14` requires `kinocut==1.15.3`. The public surface remains 201 MCP tools / 173 CLI commands.
- Live site identity reports 1.15.3. GitHub's latest release entry remains 1.15.0; MCP Registry verification was unavailable. Changes listed under Unreleased are development changes beyond these published artifacts.

## 1.15.2 - 2026-09-24

### Added
- Verified sound mastering preserves stereo through the measured mastering chain ([#523](https://github.com/KyaniteLabs/kinocut/pull/523), [#525](https://github.com/KyaniteLabs/kinocut/pull/525), [#526](https://github.com/KyaniteLabs/kinocut/pull/526)); real caption speech is processed with distance profiles; four guarded local Revideo operations are exposed with rendered-format validation ([#508](https://github.com/KyaniteLabs/kinocut/pull/508)); `release-checkpoint` passes the MCP release gate through from the CLI. Surface grows to 201 MCP tools / 173 CLI commands.

### Changed
- `sound-qa-asr` (CLI, MCP, Python client) now requires the real recognition request (`--request-json` + `--project-root`); the legacy hash/duration demo that reported `verification_status=simulated` without recognizing audio is removed and fails closed ([#432](https://git.kyanitelabs.tech/KyaniteLabs/kinocut/pulls/432)).

### Fixed
- The MCP `initialize` handshake now reports the installed kinocut version in `serverInfo.version` instead of the underlying MCP SDK version, sourced from package metadata (single source of truth; adversarial audit F1).
- An output path that resolves to a path read as an input of the same operation is now rejected with a structured `invalid_output_path` guardrail error, so `output_path == input_path` can no longer silently destroy the source file (adversarial audit F2).
- Oversized caller-supplied values echoed in error messages are truncated, so a 100 KB invalid parameter no longer amplifies into a ~200 KB error reply (adversarial audit F4).
- Absolute trim-end handling now preserves the requested endpoint ([#493](https://github.com/KyaniteLabs/kinocut/pull/493)).
- Windows drive paths survive command parsing without losing their drive prefix ([#496](https://github.com/KyaniteLabs/kinocut/pull/496)).
- CLI tests capture UTF-8 output consistently across supported consoles ([#498](https://github.com/KyaniteLabs/kinocut/pull/498)).

### Docs
- SECURITY.md now states the write-path policy plainly: relative traversal/symlink/system targets are blocked, explicit absolute output writes are allowed by design, and outputs may not alias inputs of the same operation (adversarial audit F6).

### Acknowledgements
- Thanks to [@WohaibHasan](https://github.com/WohaibHasan) for contributing [#493](https://github.com/KyaniteLabs/kinocut/pull/493), [#496](https://github.com/KyaniteLabs/kinocut/pull/496), and [#498](https://github.com/KyaniteLabs/kinocut/pull/498).

## 1.15.1 - 2026-08-31

Maintenance release: registry ownership plus the object-matte streaming port.

### Changed
- **mcp-video shim 1.6.12:** the compatibility shim carries the registry ownership marker, and the legacy `io.github.KyaniteLabs/mcp-video` registry entry was republished so directory listings (Glama, PulseMCP) point at living metadata (#469).
- **Object-matte streaming decode:** the object-matte engine now streams decode with scratch-directory caps — bounded memory on large inputs — with matching human-gate and product docs (#414, port of #412).

### Docs
- Colima warm-land recipe for CI landings, and the pinned tip SHA recorded after the #414 port (#415, #416).

## 1.15.0 - 2026-08-19

### Added
- **doctor `mcp-server-import` check:** `kino doctor` now imports the MCP server tool tree as a required core check, so it can no longer report OK while `kino --mcp` cannot start (#449, surfaced by #445).

### Changed
- **Honest MCP startup failures:** `kino --mcp` keeps the "requires the 'mcp' package" hint only when the `mcp` distribution is genuinely absent; any other server-tree import failure now prints its real cause — filesystem paths redacted, markup-safe — with a non-zero exit (#448, the second half of #445).
- **Windows test portability:** shebang-executable test stubs (fake ffmpeg/ffprobe, c2patool) skip explicitly on Windows instead of erroring at collection (#456, #450 complete).
- **Doctor import paths are platform-stable:** `kino doctor` reports the kinocut import origin with forward slashes on every OS so diagnostics compare and grep identically across Windows and POSIX.
- **UTF-8 console output:** the CLI reconfigures stdout/stderr to UTF-8 with replacement, fixing a hard `EncodeError` crash of `kino --help` on legacy cp1252 Windows consoles (caught by the new Windows CI job on its first run).

### Added
- **First-class Windows support:** portable projectstore file locking (`fcntl`/`msvcrt`) by [@gerardoscaglia-creator](https://github.com/gerardoscaglia-creator) (#446, landed with credit) — `kino --mcp` is importable on Windows; the lock backends enforce a contention-only error contract (permanent errors raise promptly; only genuine contention waits or maps to `BlockingIOError`) verified by cross-platform contract tests (#451).
- **Windows CI smoke job:** `windows-latest` runs lint, server-tree import checks, `kino doctor`, and the focused public-surface suite on every code change — Windows breakage can no longer land silently (#452).

### Fixed
- **Windows filter-option paths:** both FFmpeg unescaping passes escape filter-option paths correctly on Windows ([#458](https://github.com/KyaniteLabs/kinocut/pull/458) by [@pedropaav-art](https://github.com/pedropaav-art), merged with credit — item and credit backfilled 2026-08-31; the fix shipped in this release).
- **doctor Python floor:** `kino doctor` marks Python < 3.11 found on PATH as not-OK, with the install hint now visible in text mode too ([#459](https://github.com/KyaniteLabs/kinocut/pull/459) by [@linhaixin45-cmyk](https://github.com/linhaixin45-cmyk), merged with credit — item and credit backfilled 2026-08-31; the fix shipped in this release).

### Compatibility
- `mcp-video==1.6.11` installs `kinocut==1.15.0`.
- Published surface stays **196 MCP tools / 167 CLI commands**.

### Acknowledgements
- [@gerardoscaglia-creator](https://github.com/gerardoscaglia-creator) filed the Windows MCP-mode investigation ([#445](https://github.com/KyaniteLabs/kinocut/issues/445)) — the root-cause traceback in it exposed both diagnostics gaps fixed above — and contributed the portable file-locking fix ([#446](https://github.com/KyaniteLabs/kinocut/pull/446), landed on master with credit). Every fix in this release traces to that report. Bug reports with reproduction steps are contributions; thank you.
- [@pedropaav-art](https://github.com/pedropaav-art) contributed the Windows filter-option path escaping fix ([#458](https://github.com/KyaniteLabs/kinocut/pull/458)), which shipped in this release (credit backfilled 2026-08-31). Thank you.
- [@linhaixin45-cmyk](https://github.com/linhaixin45-cmyk) contributed the doctor Python-version floor fix ([#459](https://github.com/KyaniteLabs/kinocut/pull/459)), which shipped in this release (credit backfilled 2026-08-31). Thank you.
- Kinocut's external community predates this release: betsmayank's merged Hyperframes no-TTY fix ([#361](https://github.com/KyaniteLabs/kinocut/pull/361)), austinwmson's `remotion_still` props report ([#306](https://github.com/KyaniteLabs/kinocut/issues/306)), ismailkattakath's self-host reference stack ([#432](https://github.com/KyaniteLabs/kinocut/issues/432)), and early PRs from Dodothereal and OyaAIProd. All of them shaped the product.

## 1.14.1 - 2026-08-13

### Fixed
- **GitHub Lint / pyright:** `_handle_cancellation` is `NoReturn` so `render_rescue` type-checks on the cancel path. No runtime behavior change.

### Compatibility
- `mcp-video==1.6.10` installs `kinocut==1.14.1`.
- Published surface stays **196 MCP tools / 167 CLI commands**.

## 1.14.0 - 2026-08-13

### Added
- **360 dual-cam assembly:** Any stitched equirect MP4 (Insta360, Ricoh Theta, GoPro MAX, DJI Osmo 360, …), not X4-only. `front_back` preset plus desk/table. Raw `.insv` / `.360` rejected by suffix. One ffprobe; no stitch. Operator guide: `docs/360_ASSEMBLY.md`.
- **360/perf committee top 10:** single-pass split/pip/switch `filter_complex`; sampled quality gate (`max_analyze_seconds`); lazy `mcp_video` (no star-import); SHA-256 path/mtime cache; merge `infos=` skip-reprobe; intermediate encode flags; doctor skips `npx --yes` unless Hyperframes is on PATH and runs command checks concurrently; batched 360 storyboard stills; lazy CLI handlers + doctor/info fast-path; lazy `mcp.types` on `Client.search_tools`.

### Changed
- **Lazy public import:** `import kinocut` no longer eagerly loads Client/engines (PEP 562). `from kinocut import Client` and `kinocut.Client is mcp_video.Client` still hold.
- **Ship-seam docs:** CLI/Client `repurpose` default `--min-score` 80 and `shorts-package --allow-fail` documented. MCP durable `video_repurpose` states that `min_score` is unused.
- **ROADMAP:** pre-1.13 archaeology moved to `docs/archive/roadmap-pre-1.13.md`.
- **360 docs pass:** operator guide plus NOW / SKILL / TOOLS / PYTHON_CLIENT / CLI / README / llms honesty (no 197th-tool claim).

### Compatibility
- `mcp-video==1.6.9` installs `kinocut==1.14.0`.
- Published surface stays **196 MCP tools / 167 CLI commands**. 360 assembly reuses `video_intent` / `video_review_decide` — it is not a 197th MCP tool.

## 1.13.4 - 2026-08-12

### Added
- **`video_cutfile_render` / `cutfile-render`:** public MCP + CLI surface for thin cutfile→workflow render (Track E).
- **`video_metric_qc` / `metric-qc`:** dedicated offline metric floor tool (Phase 3).
- **Edit session close + receipt:** `session_close` writes durable conversational receipts (Track E).
- **Phase 3/4/Track E formal GO suites** with real-media metric floor, mutation fail-closed apply, OTIO IR roundtrip, G004 synthetic phone-frame fixtures, MCPB production checklist.
- **Kinocut Video CI action** now emits metric-qc + optional cutfile-render receipts and a composite `video-ci.receipt.json`.

### Changed
- Published surface **196 MCP tools / 167 CLI commands**.
- Phase 3 Watching and Phase 4 Multipliers product gates marked **GO** with linked evidence (see `docs/status/PHASE_CHECKPOINTS.md`).
- Sound S14 live re-run on apple_silicon with honest `external_host_unavailable` for second class.

### Compatibility
- `mcp-video==1.6.8` installs `kinocut==1.13.4`.
- Mutations remain human-apply only (`human_apply_required` on silent apply).

## 1.13.3 - 2026-08-12

### Added

- **Cutfile thin library render:** `kinocut.te.render_cutfile` / `compile_cutfile_to_workflow` lower schema-valid cutfiles to the existing workflow engine (no new MCP/CLI surface; optional `DEF-cutfile-mcp`).
- **Golden-path timing harness:** `scripts/golden_path_timings.py` records cheap and full-path p50/p95 baselines (`docs/status/golden-path-timings.md`).

### Changed

- **Hyperframes ops size split:** Extracted helpers into `hyperframes_ops_helpers.py` so `hyperframes_ops` stays under the 800 LOC policy; architecture guardrail locks both modules.
- **Residual portfolio honesty:** ROADMAP / PHASE / HUMAN_GATES / DEFERRED ledger for agent vs human residuals; claim-ledger freeze rules documented.

### Fixed

- Cutfile v1 rejects `composite_layers` with a clear shape error; workflow specs use unique temp files to avoid concurrent overwrites.
- Ruff F541 in golden-path timings script (CI lint).

### Compatibility

- `pip install -U kinocut` to **1.13.3**. The `mcp-video` compatibility shim **1.6.7** installs `kinocut==1.13.3`.
- Published MCP/CLI counts remain **194 / 165** (no public surface expansion).
- Cutfile render is library-only until an explicit MCP/CLI claim.

## 1.13.2 - 2026-08-09

### Security

- **C2PA tool_path injection (CRITICAL):** Removed request-controlled `c2pa_tool_path` from the public MCP tool surface. The `c2patool` executable is now resolved exclusively from operator-controlled environment variables (`KINOCUT_C2PATOOL` / `MCP_VIDEO_C2PATOOL`).
- **C2PA signer_path injection (HIGH):** Removed request-controlled `c2pa_signer_path` from the public MCP tool surface. MCP signer configuration is server-side only.
- **DNS rebinding SSRF (HIGH):** HTTP downloads in `ai_engine/download.py` now connect only to addresses resolved and validated at connect time, closing a check-then-connect TOCTOU window that DNS rebinding could exploit to reach internal services; every redirect target is re-validated before following.
- **FFmpeg filter injection (HIGH):** Validated `style["size"]` interpolation in `engine_timeline.py` before passing to FFmpeg filter strings.
- **HLS path traversal (HIGH):** Added output-path containment check in `engine_hls.py` to prevent `playlist_name` escaping `output_dir`.
- **Symlink-swap race (HIGH):** `ffmpeg_helpers.py` now uses temp-file + atomic rename to close TOCTOU window on output paths.
- **Decompression bomb (HIGH):** `image_engine.py` enforces `MAX_IMAGE_PIXELS` ceiling (50 MP) before decoding.
- **Audio synthesis OOM (HIGH):** `audio_engine/synthesis.py` caps `MAX_SYNTHESIS_SAMPLES` (10 min @ 44.1 kHz stereo).
- **Predictable temp files (HIGH):** `server_tools_audio.py` uses exclusive per-request temp files instead of predictable `/tmp` names.
- **Batch output collision (HIGH):** `engine_batch.py` generates collision-resistant output names for same-named inputs from different directories.

### Fixed

- **Published MCP tool registration (regression):** Restored the full published MCP tool surface that regressed after the 1.13.1 module split, so every advertised tool registers and stays discoverable.
- **Hyperframes preview lifecycle:** Preview servers are now tracked in a registry, replace any preview already bound to the same port, register only after a successful startup, and are terminated (SIGTERM, escalating to SIGKILL) on exit or via explicit stop controls — preventing orphaned servers and leaked ports.
- **CLI JSON stderr warnings:** Structured JSON output stays clean so consumers parsing it are not broken by stray diagnostic noise on stderr (`server_app.py`).
- **Glitch shader typed errors:** Replaced raw `RuntimeError` in `engine_glitch_shader.py` with typed `MCPVideoError` codes (`missing_node`, `shader_render_failed`, `no_frames_extracted`, `too_many_frames`, `shader_no_output`).
- **signalstats failure-log leaks:** Redacted signalstats failure output in `quality_guardrails.py` so internal FFmpeg diagnostics are neither surfaced nor logged.

### Changed

- **Performance:** signalstats queries are batched into a single `ffprobe` pass; storyboard frames extract in a single FFmpeg pass; batch operations run on a bounded thread pool; audio-only inputs skip a redundant second `ffprobe`; and audio track mixing is vectorized with NumPy.
- **CI workflow:** Replaced `actions/checkout@v4` with authenticated manual `git clone` (Colima VM cannot reach `gitea.com`). FFmpeg matrix assets switched to `linuxarm64`. Lint routed to `light` label. Base image upgraded to `ubuntu:24.04` (Python 3.12).

### Compatibility

- **Breaking (security-driven):** The request-controlled `c2pa_tool_path` and `c2pa_signer_path` parameters are removed from the public MCP tool surface. The `c2patool` executable resolves from operator environment variables and signer configuration is server-side only; MCP callers that passed these parameters must move them to operator/server configuration.
- `pip install -U kinocut` to 1.13.2. The `mcp-video` compatibility shim **1.6.6** installs `kinocut==1.13.2`. The published surface remains **194 MCP tools / 165 CLI commands**.

## 1.13.1 - 2026-08-07

### Fixed

- **`add-audio --mix` amix normalization (issue #289):** `amix=inputs=2` applied FFmpeg's default `normalize=1`, scaling each input by 1/n (−6 dB for two tracks). Added `normalize=0` so both tracks sum at unity. Verified: base −21.1 dB → mixed −18.1 dB (3 dB louder, not 6 dB quieter).
- **GitHub Actions SHA bumps:** Ported Dependabot updates for `actions/checkout` (v7.0.1), `actions/setup-python` (v7.0.0), `actions/setup-node` (SHA bump), and `pypa/gh-action-pypi-publish` (SHA bump).

### Changed

- **Module split (WP-C):** Split `hyperframes_engine.py` (1302 → 629 LOC) and `workflow/executor.py` (1000 → 665 LOC) under the 800-LOC architecture ceiling. New modules: `hyperframes_ops.py` (794), `workflow/receipt.py` (391). PEP 562 `__getattr__` re-export preserves all existing import paths.
- **README:** Added dedicated Still / Image Editing section documenting the 8 image/still CLI commands, MCP tools, and Python client methods.

## 1.13.0 - 2026-08-07

### Added

- **Intent-verb surface (P2.5):** `video_intent` / `intent` routes ~10 semantic verbs to plans without silent media mutation.
- **B-roll proposals (P2.8):** `video_propose_broll` / `propose-broll` — human-reviewable only; never silent insert.
- **Caption translation ES-first (P2.9):** `video_translate_captions` / `translate-captions` + `video_language_coverage` honesty matrix (dub not claimed as available).
- **Watching guardrail floor (P3):** `video_review_run` / `review-run`, `video_review_decide` / `review-decide`, metric QC (blackdetect/LUFS), vision QC (graceful without VLM), narrative first-15s QC, `video_propose_mutations`.
- **Timeline IR validate/compile** via existing `kinocut.timeline_ir` + OTIO JSON bridge (`video_otio_export` / `video_otio_import`).
- **Phase-4 multipliers (plan-first):** generative spend-capped plan, review HTML surface, TTS dub plan (ES-first, non-executable until backend configured).
- **TE QoL / pillars:** `init`, `estimate`, `brand-kit`, `cutfile-validate`, publish-validate, hook-candidates, audiogram plan, punch-zoom plan, seek-frame, edit-session; `.github/actions/kinocut-video-ci`.
- Devcontainer, `Dockerfile.ci`, CI topology + MCPB gate docs, directory/launch/user program ops packs; community Funnel/OAuth deploy pointer.

### Changed

- Published surface grows to **194 MCP tools / 165 CLI commands** (from 169 / 145 in 1.12.0).
- Path validation hardened for caption translate, brand kit, and OTIO artifact writes.

### Security

- Subprocess metric probes use list argv + timeouts; spend caps fail closed for paid generative plans; b-roll/mutations remain human-apply only.

### Compatibility

- `pip install -U kinocut` to 1.13.0. The `mcp-video` compatibility shim **1.6.4** installs `kinocut==1.13.0`.
- **Not claimed:** live directory listings, first-10 real-user program completion, native signed MCPB public publish, or unbounded paid generation/TTS synthesis.

## 1.12.0 - 2026-08-07

### Added

- **Still/plate editor surface** across MCP, CLI, and Python client: `still_match` / `still-match`, `still_grade` / `still-grade`, `still_gate` / `still-gate`, `image_edit` / `image-edit`, and `still_package` / `still-package`.
- Package sequence match with one shared mean-RGB gain triple (no per-frame auto-WB; sources not overwritten).
- Ordered still grade (neutralize → match → optional 3D LUT last) with signal-mode near-extrema logging.
- Fail-closed cohesion gate (luma spread + shadow green/cyan) with contact sheet and named frame failures.
- `kino doctor` `still_plates` capability check; optional `kinocut[image]` stack documents Pillow + NumPy.
- Operator docs: [`docs/STILL_PLATES.md`](docs/STILL_PLATES.md).

### Changed

- Published surface grows to **169 MCP tools / 145 CLI commands** (from 161 / 140 in 1.11.x).
- `image-edit` intent is **audit metadata only** (`intent_policy=metadata_only`); v1 pixel path is establish mean-RGB match, not NL-driven generative edit.
- Pre-release honesty pass: no double exposure scale on match; signal-mode empty bands report null rather than 0.0.
- Runtime dependency pin: `mcp>=1.27.0,<2` so clean installs do not pull MCP Python SDK 2.x (which dropped `mcp.server.fastmcp`).

### Compatibility

- `pip install -U kinocut` to 1.12.0. The `mcp-video` compatibility shim **1.6.3** installs `kinocut==1.12.0` and forwards optional extras.
- **Not claimed:** NL intent as a pixel director, full color-science grade suite, native MCPB public publish, or post-release Phase 3–4/TE pillars.

## 1.11.1 - 2026-07-24

### Fixed

- Post-theme harden on the 1.11.0 sound public surface: every discovered operation has a real fail-closed invoke path; public results reject absolute host-path leakage; package/claims/distribution pins stay lockstep at 1.11.1.
- ProjectStore compatibility tests poll for `render.completed` after a resumed job succeeds (CI free-rider).

### Changed

- Published surface remains **161 MCP tools / 140 CLI commands** (no new tool family beyond 1.11.0).

### Compatibility

- `pip install -U kinocut` to 1.11.1. The `mcp-video` compatibility shim continues to install the matching Kinocut version.
- **Not claimed:** full-episode sound completion, protected-timeline kernel, native MCPB public publish, or G004 listening closure. G004 remains a human-only production claim gate for stream-shorts.

## 1.11.0 - 2026-07-24

### Added

- Thin `kinocut_sound` S12 public join across MCP, CLI, and Python client: `sound_capabilities` / `sound-capabilities`, `sound_plan_validate` / `sound-plan-validate`, `sound_voice_batch` / `sound-voice-batch`, `sound_mix_render` / `sound-mix-render`, `sound_qa_loudness` / `sound-qa-loudness`, and `sound_qa_asr` / `sound-qa-asr` (plus matching `kino sound <action>` namespaced aliases). Operators can discover and invoke a bounded local-first sound set without private imports.
- Public discovery stays aligned with invoke: no advertised sound operation raises unknown for a valid call.

### Changed

- Published surface grows to **161 MCP tools / 140 CLI commands** (from 155 / 134 in 1.10.x). Count tests, `CLIENT_METHOD_CONTRACTS`, and the thin `server.py` facade remain in lockstep.

### Compatibility

- `pip install -U kinocut` to 1.11.0. Does **not** claim full-episode sonic-world completion, kernel integration, or production stream-shorts listening (G004 remains human-open).

## 1.10.1 - 2026-07-24

### Fixed

- Stream-shorts package fails closed when draft video bytes diverge from the render-time content hash (`source_checksum_mismatch`), so operators cannot ship a swapped file under a trusted package path.
- Program ledger honesty free-rider: ROADMAP and post-1.10 status docs mark 1.9 policy engines and 1.10 shorts as publicized; open-loops manifest banner restates historical counts; G004 remains explicitly open.

### Changed

- Published surface remains **155 MCP tools / 134 CLI commands** (patch; no new public theme).

### Compatibility

- `pip install -U kinocut` to 1.10.1. Production stream-shorts acceptance still requires human listening / phone-frame review (G004).

## 1.10.0 - 2026-07-23

### Added

- Saved-plan stream-to-shorts stages across MCP, CLI, and Python client: `shorts_plan_show` / `shorts-plan-show`, `shorts_review` / `shorts-review`, `shorts_render` / `shorts-render`, and `shorts_package` / `shorts-package`. Operators can load a persisted plan, append fail-closed human review decisions, render platform drafts (YouTube Shorts / Instagram Reels) only after a current approve, and package local manifests without any network posting.
- Operator guide [`docs/STREAM_SHORTS.md`](docs/STREAM_SHORTS.md) and an honest acceptance-status proof under `docs/proofs/` (human listening remains an explicit gate for production claims).

### Changed

- Published surface grows to **155 MCP tools / 134 CLI commands** (from 150 / 129 in 1.9.0). Public claims, count tests, and the thin `server.py` facade remain in lockstep.
- Render and package stages require output roots under the plan `output_dir` (path containment).

### Compatibility

- `pip install -U kinocut` to 1.10.0. The `mcp-video` compatibility shim continues to install the matching Kinocut version; legacy `mcp_video` imports and env vars remain supported on the 1.10.x line.
- Stream-to-shorts is operator-available. Full production acceptance still requires human listening at edit boundaries and phone-frame visual review (see `docs/proofs/2026-07-24-stream-shorts-acceptance-status.md`).

## 1.9.0 - 2026-07-15

### Added

- Public MCP, CLI, and Python-client surfaces for eight release-artifact policy engines: `video_review_package`, `video_publish_gate`, `video_review_decision`, `video_learning_report`, `video_cost_ledger`, `video_recipe_capture`, `video_capabilities`, and `video_benchmark_run`. These expose the contract-first AI-video review, publish-gate, learning, cost, recipe, capability, and benchmark engines (previously internal records) to agents and operators across all three surfaces.

### Changed

- Published surface grew to **150 MCP tools / 129 CLI commands** (from 142 / 121 in 1.8.0). All parity invariants — count tests, public doc claims, the `CLIENT_METHOD_CONTRACTS` client registry, and the `server.py` thin-facade cap — were re-synced for the cutover.

## 1.8.0 - 2026-07-14

### Added

- Added the contract-first AI-video foundation: strict canonical records, append-only private project storage, immutable content-addressed ingest, unified media preflight, temporal evidence packages, deterministic defect findings, and fail-soft optional visual providers.
- Added governed AI-video review and salvage surfaces across MCP, Python, and CLI: exact-asset verdicts and acceptance evaluation, protected-element checks, audio-preserving body swap, and lineage-bound salvage derivatives that always require fresh review.
- Added loss-proof add-audio duration policies and authored ASS plus dimension-aware SRT/VTT subtitle rendering.
- Added public operating, status, provenance, verification, and parallel-execution documentation for the unfinished AI-video and `kinocut_sound` program.
- Added a path-based `skills/kinocut-repurpose` v1 skill, install notes, and a deterministic current-tools demo script for producing local short-clip repurpose packages without inventing commands or publishing externally.
- Optional C2PA provenance signing for final MP4 exports on the existing path-based `export` / `video_export` / `Client.export()` flow. Signing remains off by default and only reports `signed` after `c2patool` signs and a follow-up verification read succeeds.
- Added a staged Kinocut MCPB package (`mcpb/`) with a valid v0.4 manifest, Node stdio launcher, local build/validation script, user-facing install docs, and explicit release gates for bundled runtimes and runtime confinement.
- Added the fail-closed native MCPB builder foundation: strict digest-pinned runtime locks, bounded portable archive extraction, target-specific manifests, and a bundle-contained launcher. Native packages remain blocked from publication pending the documented FFmpeg provenance, licensing, and clean-machine gates.

### Changed

- Approved AI-video dispositions now require active exact human decisions with requirement-level evidence; analyzer output alone cannot create approval.
- Body-swap and salvage resolve verified stored source identities and reject stale, ambiguous, aliased, or protected inputs rather than trusting ambient paths.

### Fixed

- `hyperframes_init` no longer hangs when Kinocut runs as an MCP server. Project scaffolding now always invokes the Hyperframes CLI non-interactively and with `HYPERFRAMES_SKIP_SKILLS=1` (the CLI ignores the `--skip-skills` flag and otherwise runs a blocking network AI-skills check on `init`), and every Hyperframes subprocess is run with a closed stdin so a missing TTY can never block on an interactive prompt.

### Release preparation

### Fixed

- Public S14 benchmark receipts now use an explicit allowlist and exclude machine, processor, platform, notes, status, and unknown capability data.
- The staged MCPB identity and the `mcp-video` compatibility shim now align with Kinocut 1.8.0. Native MCPB bundles remain staged/local-only and are not published.
- Thanks to @betsmayank for the Hyperframes MCP no-TTY initialization fix (#361).

### Compatibility

- `mcp-video==1.6.2` is a metadata-only upgrade shim that installs `kinocut==1.8.0` and forwards every optional extra.

## 1.7.0 - 2026-07-10

### Added

- Kinocut is now the canonical Python distribution and import package, with `kino` and `kinocut` CLI commands alongside the preserved `mcp-video` command.
- The `kinocut` npm package provides a thin `uvx` launcher for the `kino` CLI, and the MCP Registry entry now publishes under the immutable `io.github.KyaniteLabs/kinocut` identity.
- The canonical `skills/kinocut` agent skill teaches both MCP and CLI workflows; `skills/mcp-video` remains as a compatibility pointer.

### Changed

- The project, repository links, documentation, package metadata, and public discovery surfaces now use the Kinocut name and `kinocut.dev` home.
- The implementation package moved from `mcp_video` to `kinocut`. New Python integrations should import from `kinocut`.
- Current documentation, examples, workflows, active plans, and research guidance now use canonical Kinocut names, paths, install commands, and the verified 135-tool/114-command surface. Dated evidence retains its historical identity with explicit snapshot notices.
- The documentation map separates current operating guidance from historical audits, proofs, and handoffs; local Markdown links and canonical naming are enforced by public-surface tests.

### Compatibility

- `mcp-video==1.6.1` is a metadata-only upgrade shim that installs `kinocut==1.7.0` and forwards every optional extra. Existing `mcp_video` imports, `mcp-video` commands, `MCP_VIDEO_*` environment variables, `~/.mcp-video` data, `mcp-video://` resource URIs, and receipt keys remain supported through at least Kinocut 1.8.x.
- Clean installs and in-place upgrades from `mcp-video==1.6.0` are exercised as release gates, including Python imports, all three CLI entry points, package metadata, and uninstall behavior.

### Fixed

- MCP Registry metadata now uses the registry-supported GitHub mirror URL, while Forgejo remains canonical everywhere else. The publish workflow also supports a registry-only recovery dispatch, so a downstream registry rejection can be repaired without attempting to re-upload an immutable PyPI release.
- The MCP stdio handshake now reports `kinocut` as the server name instead of the retired project name.
- Contribution, testing, licensing, design-standard, integration, workflow, and agent setup docs now match the current package layout and release behavior; the Remotion removal version is corrected to v1.3.1.

## 1.6.0 - 2026-07-10

### Fixed

- Audio-only normalization now uses an audio-aware output probe, so valid WAV results no longer fail with a misleading `No video stream found` error. Audio muxing continues to validate audio inputs without video-only warnings.
- Hyperframes commands normalize a project path once at command entry, preventing relative paths such as `hyperframes` from resolving as `hyperframes/hyperframes`.
- `audio-compose` now decodes supported non-legacy WAV containers, including `WAVE_FORMAT_EXTENSIBLE`, to canonical mono signed 16-bit PCM at the requested sample rate before mixing.
- Technical and design quality checks now report shared saturation and contrast metrics with explicit units and availability. `video-quality-check --fail-on-warning` exits nonzero whenever the returned result has `all_passed: false`.
- Rescue acceptance fixtures now encode rotation with stream metadata supported by the Bookworm CI image, so the push-only slow suite runs against its installed FFmpeg instead of failing during fixture creation.

### Added

- **Post-rescue planning capabilities** - eight matching MCP, CLI, and Python client
  surfaces now expose source-backed semantic timelines and local query, reviewable timeline
  edit plans, subject-aware visual transforms, evidence-gated restoration, source-backed
  composition, capability-gated creative autopilot, and explicit remote egress contracts.
  These calls plan or verify only: they do not render, download models, submit remote jobs,
  or silently broaden an approval. See `docs/POST_RESCUE_FEATURES.md`.

- **Rescue R1 extension contracts** - immutable, versioned policy profiles; separately
  hashed feature-intent envelopes; additive verifier and capability registries; and
  deterministic preview/approval bindings now let new editing features reuse the rescue
  safety kernel without changing rescue v1 plans, receipts, hashes, or behavior.
- **Dedicated video rescue pipeline** - three additive MCP tools
  (`video_rescue_plan`, `video_rescue_render`, `video_rescue_inspect`), CLI commands
  (`rescue-plan`, `rescue-render`, `rescue-inspect`), and Python client methods now diagnose
  one local video, classify repair candidates, render approved safe IDs, and inspect a
  verified rescue package. Every successful video rescue includes a master, universal
  sharing copy, hashed receipt, and optional caption/transcript sidecars or explicit
  unavailable reasons. See `docs/RESCUE.md`.
- **Rescue FFmpeg portability gate** - the pinned FFmpeg 6/7/8 CI matrix now exercises the
  public rescue plan/render/inspect path, MOV/WebM sharing copies, and reproducible render
  contracts in addition to compositor and workflow filtergraphs.
- **`composite_layers` workflow op** — the workflow engine's allowlist grows to **7 ops**;
  a step may now compose an ordered layer stack (`op: "composite_layers"`) without leaving
  the workflow's safety envelope. Layer sources are expressed as workflow `@refs`
  (`inputs.layers[].src` / `.mask` → `@sources.<id>` / `@work/<name>`), never as nested or
  raw paths (those fail closed with `unsafe_workflow_source`). Every layer source is
  resolved, workspace-confined, and hashed into the step's `input_hashes` (one sha256 per
  layer source), and the workflow layer synthesizes a workspace-confined nested spec that
  the vetted `composite_layers` engine consumes — so composite provenance matches every
  other op. The only tunable param is `canvas`; output uses the normal
  `@work`/`@outputs` binding + `output_hash`. This rides the existing `video_workflow_*`
  tools / `workflow-*` CLI (no new tool or command). See `docs/WORKFLOWS.md`.

### Safety

- Rescue is local-only, source-immutable, and timeline-locked. Plan/source/policy/dependency
  staleness and invalid approvals fail closed; cancellation never promotes output;
  verification failures are quarantined; resumable intermediates require matching hashes;
  and all promoted artifacts have receipt hashes and explicit verification metrics/units.
  Captions remain sidecars and rescue never downloads Whisper or invokes cloud processing.

### Compatibility

- Existing MCP, CLI, and Python APIs are unchanged. Whisper remains optional, the universal
  sharing copy is additive to the high-quality master, and intentional 24 fps delivery
  behavior elsewhere in MCP Video is unchanged.

### Security

- **Workflow artifact writes are confined to the spec's workspace root (R1)** — `--save-plan`,
  `--save-receipt`, and `--save-receipt-dir` now additionally require the resolved target to
  live UNDER the spec's workspace directory (the same realpath + `relative_to` confinement
  every declared source and output already obeys), on top of the existing
  traversal/symlink/system-dir/dotfile guard. A `.json` write that passed the media guard but
  pointed outside the workspace now fails closed with `unsafe_workflow_source`.
- **Out-of-workspace absolute paths redacted in workflow errors (R2)** — a wrapped engine
  fault whose message embeds an absolute home path (`/Users/<name>/…`, `/home/<name>/…`)
  outside the workspace is now redacted to `<redacted-path>` in both the raised
  `MCPVideoError` and the receipt's recorded step error, closing a residual path leak beyond
  the workspace-prefix strip.

### Added

- **Agent workflow engine** — a new `video_workflow_*` MCP tool family (`video_workflow_validate`, `video_workflow_plan`, `video_workflow_render`, `video_workflow_inspect`) plus flat CLI commands (`workflow-validate`, `workflow-plan`, `workflow-render`, `workflow-inspect`) and Python client parity (`Client.workflow_validate/plan/render/inspect`). An agent can define a multi-step local video job as a JSON spec (`schema_version: 1`), validate it cheaply, produce a no-render dry-run plan, render it with a provenance receipt, and inspect that receipt afterward. Steps are an ordered, backward-reference-only list over a fixed 6-op allowlist (`probe`, `trim`, `resize`, `convert`, `merge`, `add_text`), each backed by an existing vetted engine; unknown ops, forward/unknown `@refs`, and workspace-escaping paths fail closed with `MCPVideoError` codes.
- **Workflow resume, variants, and cleanup** — `video_workflow_render --resume <receipt>` continues a partially-completed job (spec-hash gated; a step is reused only when it is completed AND its output and input hashes still match); `variants[].overrides` emit N outputs from one source/step declaration; intermediates in the job's isolated `@work/` directory are cleaned on success, kept on failure, and `--keep-intermediates` overrides cleanup for inspection.
- **Compositor full-canvas blend modes** — `composite-layers` / `video_composite_layers` layers accept `blend` values `multiply`, `screen`, `overlay`, `darken`, `lighten`, applied full-canvas via the FFmpeg `blend` filter. Positioned/scaled/masked/timed blend is deferred and fails closed with the new `unsupported_blend_geometry` code; unknown modes fail closed with `unsupported_blend_mode`.
- **Compositor rotation and pivot** — layers accept `rotation` (degrees, transparent-fill) and a new `pivot` field (`center` default, plus the four corners) setting the rotation/placement reference point. The existing `anchor` position alias is unchanged. Unknown pivots and non-numeric rotation fail closed.
- `composite-layers` / `video_composite_layers` P2 supports transform sizing, timing windows, mask/matte alpha sources, dry-run layer plans, source/output hashes, and richer render receipts for agent review before publishing.
- `video_duck_audio`: mix background music under a video's voice with automatic sidechain ducking — the music dips during speech and recovers in pauses. Engine function `duck_audio` with validated `music_volume`, `threshold`, `ratio`, `attack`, and `release` parameters.
- `video_ai_color_grade` accepts `lut_path` for professional `.cube`/`.3dl` LUT files via FFmpeg `lut3d`, overriding style presets and reference matching.
- `video_convert` streams MCP progress notifications during long renders, so clients can show a live percentage instead of an apparently hung call.
- Spanish-language README section (`En español`) and bilingual EN/ES text for the most common errors (FFmpeg missing, file not found).
- New docs for the release surface: `docs/WORKFLOWS.md` (workflow engine), workflow + layer_plan receipt schemas in `docs/VIDEO_RECEIPT.md`, and a receipt-privacy scan test that fails on any home path, username-in-path, or secret-shaped token in committed docs/examples or freshly produced dry-run/render artifacts.

### Changed

- **`layer_plan` receipt bumped to `schema_version: 2`** (backward-readable, additive). It gains a `receipt_kind` discriminator (`"layer_plan"`), `transform.rotation`/`transform.pivot` fields, blend/rotation `features` flags, and an explicit `audio_policy: "dropped_video_only"` flag (composite output stays video-only this release; audio compositing is deferred, documented, and receipt-flagged rather than silent). `video_workflow_inspect` reads both new workflow receipts and legacy `receipt_kind`-less v1 layer_plan receipts by inferring the kind.
- Glitch tools (`glitch_rgb_shift`, `glitch_scanline_jitter`, `glitch_screen_tearing`, `glitch_vhs_tracking`, `glitch_macroblocking`, `glitch_datamoshing`, `glitch_cmyk_split`, `glitch_turbulent_displacement`) now return rich edit metadata in their MCP responses — `duration`, `resolution`, `size_mb`, and `elapsed_ms` — matching the envelope shape of all other edit tools. Previously these tools returned only `success` and `output_path`.

### Fixed

- The `composite-layers` layer-plan receipt now records `output_path` (and `resolved_src`/`mask`) relative to the spec directory whenever the file lives inside it, instead of emitting the resolved absolute path — a shared or committed receipt no longer leaks the user's home directory. Internal rendering still uses the resolved absolute location; only the receipt is relativized.
- Removed BasicPitch from declared optional extras and documented it as a manual integration so Dependabot can patch vulnerable TensorFlow/Keras/protobuf transitive dependencies instead of resolving an unsafe pinned stack.

### Security

- **Workflow param VALUE validation** — a step's `params` values are now type-checked against the backing engine's parameter types (not just names), so a string for an integer parameter (e.g. `width="20000"`, `size="24,drawtext=textfile=/etc/hosts"`) fails closed with `invalid_workflow_params` before any FFmpeg invocation. Engine sinks are independently hardened: `resize` rejects non-integer/oversize dimensions and `add_text` coerces `fontsize` through a numeric guard before filtergraph interpolation.
- **Workflow artifact write-path validation** — `--save-plan`, `--save-receipt`, and `--save-receipt-dir` now route through the same traversal/symlink/system-directory/sensitive-dotfile guard as media outputs and additionally refuse to overwrite any file that is not a `.json` artifact, closing an arbitrary out-of-workspace overwrite that previously only rejected null bytes.
- **Workflow resource caps** — a spec may declare at most 64 steps and 32 variants, and `resize` dimensions are bounded to 7680px; exceeding a cap fails closed.
- **`add_text` `font` excluded from workflow specs** — the path-typed `font` parameter (a filesystem existence oracle) is no longer tunable through a workflow op and fails closed as an unaccepted param; set fonts by calling `add_text` directly.
- Workflow steps now fail closed on ANY engine exception (not only `MCPVideoError`): an unexpected runtime fault is wrapped as `workflow_step_failed`, recorded on the receipt with a workspace-sanitized message, and left resumable; the Python client rejects a dict spec for render; batch variants that resolve to a colliding output path fail closed; and raw-relative input refs are re-confined to the workspace at execution time (closing a validate→execute symlink TOCTOU).

### Removed

- The opt-in anonymous analytics ping (`MCP_VIDEO_ANALYTICS=1`). The endpoint it posted to was never deployed or owned by the project, making the domain claimable by a third party — removed entirely rather than left as a silent no-op.
- `video_generate_music` and the MiniMax music API integration. A hosted, per-key music API does not belong in a local-first tool; background-music generation moves to a local open-source pipeline (planned: ACE-Step) with mcp-video handling the mixing via `video_duck_audio`.

## 1.5.2 - 2026-07-06

### Added

- Added `composite-layers` / `video_composite_layers` P1 for ordered image/video/solid layer stacks with normal alpha compositing, per-layer opacity, fixed x/y placement, and deterministic layer-plan receipts.
- Added Python client parity for `Client.composite_layers(...)`.

### Changed

- Routed Forgejo CI required jobs to the known-live `light` runner label so PR and post-merge checks do not wait on optional heavyweight runners.
- Aligned package metadata with the Forgejo repository as the canonical source while preserving MCP Registry identity.

### Fixed

- Guarded glitch shader ffprobe subprocess calls with timeout-aware error handling.
- Removed tracked local `.pi-lens` cache artifacts and scrubbed public local-infrastructure references from agent guidance files.
- Added release-hardening checks to prevent local path/cache leakage from returning.

## 1.5.1 - 2026-06-04

### Fixed

- Removed the unpublished `meltysynth` dependency from optional audio extras so Glama, uv, and package metadata validators can resolve the project.
- Updated the repository readiness audit after the intentionally removed `/explainer-video` npm Dependabot entry.

## 1.5.0 - 2026-06-04

### Added

- Added Video Receipt documentation for agent-created media review trails.
- Added receipt-backed confidence baseline workflow with quality report, release checkpoint, storyboard, thumbnail, and pending human-review status.
- Added local repurpose-package workflow for platform variants with manifest, review artifacts, checkpoints, and receipt output.
- Added confidence benchmark and adversarial certification scripts for local readiness proof.
- Added dated proof notes for fresh install confidence, public issue triage, agentic media readiness, and external feedback asks.

### Changed

- Hardened the explainer workflow into a 10-stage receipt-producing lane with transition audit records, audio normalization, quality report, and a real `min_score=50` release checkpoint.
- Updated workflow routing docs and golden workflow map around the confidence proof lanes.

### Fixed

- Removed the stale Dependabot `/explainer-video` npm configuration entry so dependency automation can run against real package paths.
- Made corrupted media probing fail as `InputFileError`, giving adversarial checks a clear invalid-input signal.
- Fixed the confidence benchmark so stale receipts cannot hide a failed workflow run.

## 1.4.1 - 2026-05-25

### Added

- Added preflight guardrails for high-risk video/audio edit paths:
  - `video_filter` warns and clamps out-of-range filter parameters.
  - `video_merge` warns on resolution/FPS/audio mismatches and rejects transitions longer than the shortest clip.
  - `video_add_audio` validates volume and warns on mix/timing risks.
  - `video_overlay`, `video_watermark`, and `video_chroma_key` validate opacity/similarity/blend/timing parameters.
  - `video_text_animated` validates color, start/duration, and warns on timing/overflow risks.
  - `video_layout_grid` and `video_split_screen` warn on clip-count, duration, FPS, and audio mismatches.
- Added tracked implementation plan at `docs/plans/2026-05-24-video-guardrails.md`.

### Changed

- Refreshed README, tool reference, landing page, roadmap, contribution guide, package metadata, and GitHub repository description for the current 119-tool guardrailed surface.

## 1.4.0 - 2026-05-09

### Added

- Expanded Hyperframes orchestration for the 0.5 surface: snapshots, inspection, metadata, catalog, website capture, local TTS, transcription, background removal, diagnostics, benchmarks, and richer render controls.
- Added local video repurposing helpers for dry-run manifests and platform-ready variants with thumbnails, storyboards, and optional release checkpoints.
- Real `analyze_video(include_colors=True)` color extraction — returns actual dominant colors instead of placeholder values.
- `video_info_detailed` now returns real dominant colors instead of `None`.

### Changed

- Refreshed README, MCP tool docs, Python client docs, AI discovery, and `llms.txt` so PUSHING CREATION, Hyperframes, and repurposing are described as the current operator paths without centering test-count messaging.
- Pipeline cleanup `OSError`s are now surfaced as warnings instead of being silently swallowed.

### Fixed

- Fixed green-cast video effects and 24-bit WAV handling in `effect_noise`, `video_overlay`, and audio effects.
- Fixed 24-bit WAV handling in `audio_compose`.
- Design quality probe now returns `None` on analysis failure instead of sentinel values (128 luma, 50 contrast) that produced perfect scores.
- Typography check adds an advisory issue when brightness analysis is unavailable.
- Reject unsupported Hyperframes render dimensions instead of silently accepting them.
- Report Hyperframes render artifacts correctly by output format, including `png-sequence` directories.
- Fail Hyperframes render-and-post/pipeline paths when render artifacts are missing.
- Reject unknown text animations instead of silently ignoring them.
- Reject empty animated text at engine and MCP/tool layers.
- Reject invalid layout/PIP choices at tool and engine boundaries.
- Validate mograph duration/fps/style and reject unknown progress style.
- Reject unknown animated text positions.
- Reject unknown watermark/overlay positions.
- Reject malformed timeline image overlay position dicts before input probing.
- Validate convert format/quality before probe/FFmpeg.
- Validate HLS qualities and segment duration before probe/FFmpeg.
- Reject unsupported `compare_quality` metrics instead of reporting meaningless `unknown`.
- Validate `video_batch` operation names before input path validation.
- Validate malformed subtitle entries/ranges before input path validation.
- `audio_compose()` rejects missing track files, empty tracks, non-dict entries, non-positive duration, and invalid volume.
- `audio_sequence()` rejects unknown/missing event types and unsupported tone waveforms.
- `audio_effects()` rejects unknown/missing effect types.
- `audio_preset()` rejects invalid pitch and intensity.
- `audio_synthesize(effects={...})` rejects unknown effect keys.

## 1.3.10 - 2026-05-07

### Fixed

- Improved `mcp-video doctor` guidance on Python 3.13+ so missing Real-ESRGAN/BasicSR reports explain the BasicSR build guard and point users to the OpenCV fallback or Python 3.11/3.12 for the Real-ESRGAN backend.

## 1.3.9 - 2026-05-06

### Fixed

- Fixed `mcp-video[all-ai]` and `mcp-video[upscale]` installs on Python 3.13 by guarding Real-ESRGAN/BasicSR dependencies behind the Python versions where BasicSR still builds, while keeping the OpenCV upscaling fallback installable.

## 1.3.8 - 2026-05-06

### Fixed

- Fixed AI scene-detection JSON output so perceptual-hash differences are serialized as standard JSON numbers.
- Added `torchcodec` to stem-separation extras and diagnostics so Demucs output works with current TorchAudio save behavior.

## 1.3.7 - 2026-05-06

### Fixed

- Fixed `search_tools()` / `Client.search_tools()` so discovery includes the full 91-tool MCP surface, including PUSHING CREATION, Hyperframes, audio, and AI tools.

## 1.3.6 - 2026-05-06

### Added

- Added PUSHING CREATION-compatible cinematic pre-production tools:
  - `video_project_create`
  - `style_pack_read`
  - `storyboard_read`
  - `shot_prompt_render`

### Changed

- Updated package, MCP registry metadata, README, `llms.txt`, and tool docs for the 91-tool cinematic creation surface.
- Toned down public launch copy so test coverage is supporting evidence rather than the main product message.

### Fixed

- Restored README readiness anchors required by the repository audit.

## 1.3.1 - 2026-05-03

### Security

- Fixed command injection risk in `engine_stabilize.py` — vectors file path now validated as absolute.
- Enabled SSL certificate verification for AI model downloads in `ai_engine/upscale.py`.
- Redacted full filesystem paths from stabilization error messages.

### Fixed

- Added proper AI operation timeout (3600s) for demucs/whisper — prevents premature kills on long videos.
- Increased FFmpeg stderr buffer from 1MB to 10MB — fixes truncated progress for long-running operations.
- Fixed temp file leak in typewriter text effect — cleanup now happens even on write failure.
- Added `OSError` handling in hyperframes for file size race conditions.
- Added pitch shift semitones range validation (-48 to +48) — prevents FFmpeg filter chain overflow.
- Capped pixel count in color extraction (50K max) — prevents memory exhaustion on large images.
- Added try-finally cleanup for Whisper temp WAV files.
- Added bitrate/size range validation in probe before integer conversion.
- Added 1MB JSON size limit in CLI argument parser.
- Added `threading.Lock` for thread-safe probe cache.
- Centralized all timeout constants in `limits.py`.

### Changed

- Standardized tool count to **87 MCP tools** across all documentation and metadata files.
- Removed duplicate Hyperframes Integration section from README.
- Removed duplicate architecture entry from README.
- Documented `video_cleanup` tool in TOOLS.md.
- Updated test count in TESTING.md.
- Marked shipped v1.3.0 features as completed in ROADMAP.md.
- Updated server.json version to 1.3.1.

### Removed

- **Remotion integration completely removed.** All Remotion MCP tools, CLI commands, client methods, engine modules, and tests have been deleted. The project now uses Hyperframes (HTML-native, Apache 2.0) as its sole code-based video creation engine.
  - Deleted: `mcp_video/remotion_engine.py`, `mcp_video/remotion_models.py`, `mcp_video/server_tools_remotion.py`, `mcp_video/client/remotion.py`, `mcp_video/cli/handlers_remotion.py`, `mcp_video/cli/parser/remotion.py`, `tests/test_remotion_engine.py`, `tests/test_remotion_deprecation.py`
  - Removed `RemotionNotFoundError`, `RemotionProjectError`, `RemotionRenderError` from `errors.py`
  - Removed `VALID_REMOTION_TEMPLATES` from `validation.py`
  - Removed Remotion category from `doctor.py` checks
  - Updated `test_public_surface.py`: 87 MCP tools (was 93), 88 CLI commands (was 94)
  - Removed `remotion` optional dependency, pytest marker, and keyword from `pyproject.toml`
  - Removed Remotion CI smoke test job
  - Updated all documentation to remove Remotion references

### Design

- Redesigned landing page: Space Grotesk + DM Sans typography, orange/teal video-editing palette.
- Fixed broken mobile menu with proper responsive CSS.
- Added inline SVG favicon, ARIA labels, skip-to-content link.
- Improved hero headline: "87 Video Tools. Zero Cloud Costs."
- Added Organization schema markup for better SEO.
- Optimized font loading with preconnect hints.

## 1.3.0 - 2026-04-28

### Added

- **Crop by percentage** — `crop()` now accepts `crop_percent` (e.g. `crop_percent=50` for a center 50% crop). Alternative to explicit `width` + `height`.
- **Orientation-aware metadata** — `VideoInfo` now exposes `rotation`, `display_width`, `display_height`, and `display_resolution`. ffprobe `side_data_list` is parsed for rotation metadata.
- **Audio waveform text representation** — `WaveformResult.text` returns an ASCII art waveform for agent-friendly display.
- **Frame-accurate seeking** — `trim()` gains `accurate=True` for output-seeking (slower, frame-perfect) vs the default fast input-seeking.
- **Pipeline output cleanup** — `Client.pipeline()` gains `cleanup=True` to auto-remove intermediate files after chaining.
- **Structured logging** — New `--verbose` / `-v` CLI flag enables DEBUG logging to stderr.
- **Template preview** — `preview_template()` returns operations list + estimated output before rendering a timeline template.
- **Custom font upload** — `font_manager.py` downloads and caches Google Fonts by name for use in text overlays.
- **Usage analytics** — `analytics.py` sends an optional anonymous ping on server startup. Disable with `MCP_VIDEO_ANALYTICS=0`.
- **HLS/DASH streaming** — `hls_segment()` segments video into HTTP Live Streaming format with multi-quality variants.
- **Advanced codecs** — `convert()` now supports `hevc` (H.265), `av1`, and `prores` output formats.
- **Advanced masking** — New `luma_key()` (brightness-based masking) and `shape_mask()` (circle, rounded_rect, oval) tools.
- **Smarter GIF output** — Quality-based fps scaling (10/12/15/20), Bayer dithering, and 128-color palette generation.

### Changed

- **Merge auto-normalize** now handles fps mismatches, audio sample rate mismatches, and rotation-aware display dimensions during normalization.
- **Remotion deprecation upgraded** from `DeprecationWarning` to `FutureWarning` for v1.3.0 timeline.
- Public tool count updated from 90 to **87** unique MCP tools.

### Fixed

- `convert()` vs `export_video()` docstrings clarified to distinguish format changes from quality-tuned delivery.

## 1.2.6 - 2026-04-27

### Changed

- Bumped version to 1.2.6 (1.2.5 tag already existed).

## 1.2.5 - 2026-04-27

### Added

- **Hyperframes integration** — 8 new MCP tools, Python client methods, and CLI commands for HTML-native video creation:
  - `hyperframes_init` — scaffold new projects (blank, warm-grain, swiss-grid templates)
  - `hyperframes_render` — render compositions to MP4/WebM/MOV
  - `hyperframes_still` — render single frames via snapshot
  - `hyperframes_compositions` — list compositions in a project
  - `hyperframes_preview` — launch live preview studio
  - `hyperframes_validate` — validate project structure and run lint
  - `hyperframes_add_block` — install blocks from the Hyperframes catalog
  - `hyperframes_to_mcpvideo` — render then post-process with mcp-video in one step
- Full test suite for Hyperframes engine: 54 unit + integration tests in `tests/test_hyperframes_engine.py`.
- `sample_hyperframes_project` pytest fixture.

### Changed

- **Remotion is deprecated.** All Remotion MCP tools, client methods, and CLI commands now emit `DeprecationWarning`. Remotion will be removed in a future major version. Migrate to Hyperframes (Apache 2.0) or Revideo (MIT).
- Public tool count updated from 82 to 90 unique MCP tools.
- `mcp_video/client/remotion.py` — all methods now warn on usage.

### Fixed

- `hyperframes_engine.validate()` no longer raises `HyperframesProjectError` when no HTML entry point is found; it correctly reports the issue in the validation result.

## 1.2.4 - 2026-04-22

### Added
- `Client.subtitles_styled()` alias for `text_subtitles()` to match MCP tool rename.
- Runnable `workflow.py` for `02-podcast-clip` (6 stages).
- Runnable `workflow.py` for `03-explainer-video` (7 stages, client-only, no raw FFmpeg).

### Changed
- Documentation updated for `search_tools`, `workflows/`, and ICM alignment.
- `workflows/01-social-media-clip/workflow.py` fixed client arg names.

## 1.2.3 - 2026-04-22

### Changed

- Consolidated duplicate tools: removed `video_blur`, `video_color_grade`, and `video_extract_frame` as standalone tools. Functionality preserved through `video_filter` and `video_thumbnail`.
- Renamed `video_text_subtitles` to `video_subtitles_styled` for clearer naming.
- Added `search_tools` meta-tool for fast tool discovery by keyword.
- Updated public tool count from 83 to 81 unique tools.
- Reorganized docs/TOOLS.md into 12 functional categories.

### Fixed

- Image analysis tools (`image_extract_colors`, `image_generate_palette`, `image_analyze_product`) now accept video input by auto-extracting a representative frame.

### Added

- Added ICM-style `workflows/` directory with 3 production-ready pipelines: social-media-clip, podcast-clip, and explainer-video.
- Added `CLAUDE.md` and `workflows/CONTEXT.md` for agent context routing.

## 1.2.2 - 2026-04-21

### Added

- Added GitHub Discussions templates, CODEOWNERS, maintainer/governance docs, and Dependabot configuration.
- Added `llms.txt`, `robots.txt`, `sitemap.xml`, and `server.json` for search, AI-agent discovery, and MCP Registry readiness.
- Added `docs/AI_AGENT_DISCOVERY.md` and an adversarial remediation plan.
- Added `_validate_output_path()` and rolled it out across all engines for safer output directory handling.
- Added client-side validation and return type annotations for improved API contract consistency.
- Added current edge-case audit document (`docs/CURRENT_EDGE_CASE_AUDIT_2026-04-21.md`).

### Changed

- Updated public tool count messaging from 82 to the current 83 MCP tools.
- Updated the landing page with crawl metadata and structured software/source metadata.
- Normalized root metadata links to the canonical repository URL.
- Replaced the grey social preview image with generated media artwork.

### Security

- Fixed TOCTOU race conditions and sanitized numeric values in FFmpeg filters.
- Hardened AI engine resource guards for scene detection, spatial audio, stem separation, transcription, and upscaling.
- Hardened direct download paths with timeout and size limits.
- Closed top-priority audit validation gaps across engine boundaries.
- Fixed design quality security and SRT format safety issues.

### Fixed

- Added startup validation to `remotion_engine.studio()` to catch immediate process crashes.

## 1.2.1 - 2026-04-13

### Changed

- Prepared the 1.2.1 package metadata and public badge.
- Improved runtime error contracts and diagnostics.
- Repaired repository trust rails for deploys, packages, tests, and AI extras.

### Fixed

- Aligned `mcp_video.__version__` with the package version in `pyproject.toml`.
- Moved optional dependency metadata out of Ruff configuration.
- Centralized chroma-key color validation for safer FFmpeg filter construction.

## 1.2.0 - 2026-03-31

### Added

- Published the 1.2.0 package release.
- Documented the broad MCP, CLI, Python client, FFmpeg, Remotion, image, audio, AI, and quality-guardrail surface.
