<!-- mcp-name: io.github.KyaniteLabs/mcp-video -->
# mcp-video is now Kinocut

This package preserves existing installs after the project rename. It installs the matching
Kinocut release and keeps the `mcp-video` command and `mcp_video` Python import working.

New installations should use:

```bash
pip install kinocut==2.0.1
kino doctor
```

When upgrading an older shim, reinstall its matching canonical release after
the upgrade. Older installer records can remove the shared executable even when
`pip check` reports no dependency conflict:

```bash
python -m pip install --upgrade 'mcp-video==1.6.22'
python -m pip install --force-reinstall --no-deps 'kinocut==2.0.1'
python -m pip check
kino --version
kinocut --version
mcp-video --version
```

Preserve configured extras during the first upgrade. The new shim owns no console
scripts; after this repair, removing it preserves all three canonical aliases.

Compatibility identifiers remain supported on the published Kinocut 2.0.x line
and the prior 1.16.x line. Project home:
[kinocut.dev](https://kinocut.dev/).

## License

Apache License 2.0 — the same license as Kinocut itself. The full text ships
as `LICENSE` alongside this README in the source distribution and inside the
wheel (`mcp_video-<version>.dist-info/licenses/LICENSE`), and lives at the
[repository root](https://github.com/KyaniteLabs/kinocut/blob/master/LICENSE).
